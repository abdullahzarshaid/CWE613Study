"""Print the archived repeat-coding comparison without modifying reference files."""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'analysis'))
import measurement as m
if __name__=='__main__':
    result=m.calculate(m.read('ANNOTATIONS_609.json'),m.read('AUDIT_LABELS_120.json'),m.read('BALANCED_60.json'),m.read('NEIGHBOR_236.json'))
    print(json.dumps(result['audit'],indent=2))
