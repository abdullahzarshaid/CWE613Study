SUPPLEMENT S1

Logout Is Not Expiration: A Source-Aware Semantic Characterization of CWE-613
Abdullah Bin Zarshaid and Shahbaz Akhtar Siddiqui

This package accompanies the revised manuscript in manuscript/Paper.pdf.
It contains the retained data, evidence, analysis code, figure sources and
synthetic laboratory needed to reproduce the reported measurements.

START HERE

1. Read Methods.txt for the evidence conditions, source limits and provenance.
2. Open dataset/Codebook.txt and dataset/DataDictionary.txt for the coding
   rules, field meanings and CSV schemas.
3. Use evidence/EvidenceMap.txt to locate support for the paper's claims.
4. Read evidence/Rights.txt before any public redistribution.

REPRODUCTION

Extract the ZIP first. Open a terminal in the Supplement folder, not inside
analysis. Use Python 3.11 or later. The tested local environment is recorded
in analysis/Environment.txt. Plotting requires Matplotlib and NumPy:

    python -m pip install -r analysis/requirements.txt

Verify the supplied files, reproduce the results, then verify again:

    python analysis/reproduce.py --verify-only
    python analysis/reproduce.py
    python analysis/reproduce.py --verify-only

To rebuild the paper as well, install pdfLaTeX and BibTeX and run:

    python analysis/reproduce.py --pdf

Without plotting dependencies, use:

    python analysis/reproduce.py --no-figures

The laboratory uses only Python's standard library and local loopback ports.
The reproduction command does not call an AI service, download new CVEs or
require an API key. Dependencies must be installed separately if absent.

Successful reproduction prints status PASS. It checks 609 records, compares
61 generated result files, regenerates seven figures when requested, and
runs the retained research and software tests. The laboratory has eight
mechanisms, 16 scenarios, 399 HTTP steps and 48 constructed control checks.
A deliberately vulnerable configuration violates its denial invariant; that
is its expected witness outcome, not a failed overall experiment.

Generated artifacts go under build/. Reference results remain unchanged.
Do not regenerate the checksum manifest to bypass a verification failure.
Different plotting or TeX environments can produce different PDF bytes;
scientific values and test contracts must still agree.

CONTENTS

analysis        Measurement, export, plotting, reproduction and tests.
catalogue       Retained CWE releases and selected mapping chronology.
checks          Release checksums and protected input/output inventories.
classifications Historical, V1 and V2 summary labels and transitions.
consistency     The archived 120-record digital comparison and scoring guide.
dataset         The 609-record corpus, source metadata, codebook and schemas.
evidence        Claim map, source locators, reference audit and rights notices.
manuscript      The matching paper, LaTeX source, tables and vector figures.
neighbours      The 92 CWE-672 and 144 selected CWE-384 records.
outputs         Reference measurements, figure specifications and reporting views.
records         Retained public descriptions, exact spans and decision summaries.
reference       Reference results for the separate expiration fixtures.
sesstrace       The withdrawal and expiration laboratory, tests and traces.
sources         The 60-record advisory comparison and 97 recorded source attempts.

The file names used by scientific data and Python code are retained where
needed for compatibility. Human-facing instructions have simple names.
Internal language reviews, biography exports, edit histories and successive
QA narratives are not part of this reviewer package.

SCOPE

The research labels, numerical observations and laboratory are unchanged.
The matching paper includes author ORCIDs, the received CWE proposal note,
a focused future-research subsection, and the authors' report of completed
digitization. This package reproduces the retained records and measurements,
not missing historical annual feeds, original API pages, full advisory caches
or the original neighbour-screen implementation. Actual paired human ratings
are not inputs in this ZIP; no human agreement value has been invented.

Use this Supplement.zip with the title-named manuscript PDF and Overleaf.zip
delivered with it. The embedded manuscript/Paper.pdf is the same PDF. Older papers and supplements should not be mixed with this release.
Provide the files through the journal's approved supplementary or reviewer-
access route and confirm distribution rights. This package does not confer
journal acceptance or an open licence.
