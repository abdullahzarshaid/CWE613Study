"""Revision regression tests. Human-label examples here are synthetic test data only."""
from pathlib import Path
from collections import Counter
import hashlib,json,tempfile,unittest
import measurement as m
import supplementary_analysis as sa
from score_human_pairs import score
from export_results import generate

class RevisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.data=sa.compute()
    def test_reporting_view_preserves_frozen_labels(self):
        original={r['id']:r for r in m.read('ANNOTATIONS_609.json')}
        for r in self.data['record_axes']:
            self.assertEqual(r['summary_class'],original[r['id']]['v2_class'])
            self.assertEqual(r['source_sha256'],original[r['id']]['source_sha256'])
            if r['summary_class']=='I':self.assertIsNone(r['mechanism_summary'])
    def test_unassessed_is_not_false(self):
        for r in self.data['record_axes']:
            for c in 'ABT':self.assertIn(r[c+'_status'],{'assigned','alternative','not_assessed_as_coexisting'})
    def test_joint_evidence_partition(self):
        r=self.data['evidence_partition']
        self.assertEqual(sum(x['n'] for x in r),280)
        self.assertEqual(sum(x['n'] for x in r if x['scope']=='unresolved'),1)
    def test_missingness_totals_for_every_grouping(self):
        rows=self.data['source_missingness']
        for d in {r['dimension'] for r in rows}:
            self.assertEqual(sum(r['selected'] for r in rows if r['dimension']==d),60)
            self.assertEqual(sum(r['unevaluable'] for r in rows if r['dimension']==d),18)
    def test_co_cwe_counts_are_per_record(self):
        x=next(r for r in self.data['co_cwe'] if r['co_cwe']=='CWE-384')
        self.assertEqual(x['n'],17)
        self.assertEqual(sum(x[c] for c in m.CLASSES),17)
    def test_export_isolated(self):
        sources=[m.ROOT/'dataset/CWE613_annotations_609.json',m.ROOT/'outputs/RESULTS.json',m.ROOT/'manuscript/paper.tex']
        before=[p.read_bytes() for p in sources]
        with tempfile.TemporaryDirectory() as t:
            result=generate(Path(t));self.assertEqual(result['class_counts']['v2']['A'],134)
            self.assertTrue((Path(t)/'outputs/supplementary/record_axes.json').is_file())
        self.assertEqual(before,[p.read_bytes() for p in sources])
    def test_generated_macros_are_used(self):
        import re
        paper=(m.ROOT/'manuscript/paper.tex').read_text()
        names=re.findall(r'\\newcommand\{\\(\w+)\}',(m.ROOT/'manuscript/generated/numbers.tex').read_text())
        self.assertEqual(len(names),13)
        for name in names:self.assertRegex(paper,r'\\'+name+r'\b')
    def test_event_annotations_not_confused_with_unique_records(self):
        row=next(r for r in self.data['event_count_units'] if r['event']=='time-expiration')
        self.assertEqual(row['event_annotations'],155)
        self.assertEqual(row['distinct_records'],154)
    def test_laboratory_totals_remain_separate(self):
        a=m.read('sesstrace/results/benchmark_results.json')['summary']
        b=m.read('reference/expiration/expiry_results.json')['summary']
        self.assertEqual(a['n_http_steps'],363);self.assertEqual(b['n_http_steps'],36)
        self.assertEqual(a['n_http_steps']+b['n_http_steps'],399)
    def test_human_agreement_perfect_synthetic(self):
        x=score([{'id':'TEST_A','human_1':'A','human_2':'A'},{'id':'TEST_B','human_1':'B','human_2':'B'}])
        self.assertEqual(x['cohen_kappa'],1);self.assertEqual(x['krippendorff_alpha_nominal'],1)
    def test_human_agreement_disagreement_synthetic(self):
        x=score([{'id':'TEST_1','human_1':'A','human_2':'B'},{'id':'TEST_2','human_1':'B','human_2':'A'}])
        self.assertEqual(x['cohen_kappa'],-1)
        self.assertAlmostEqual(x['krippendorff_alpha_nominal'],-.5)
    def test_degenerate_human_coefficient_is_not_invented(self):
        x=score([{'id':'TEST_1','human_1':'A','human_2':'A'},{'id':'TEST_2','human_1':'A','human_2':'A'}])
        self.assertIsNone(x['cohen_kappa']);self.assertIsNone(x['krippendorff_alpha_nominal'])
    def test_missing_human_values_are_rejected(self):
        with self.assertRaises(ValueError):score([{'id':'TEST_1','human_1':'A','human_2':''},{'id':'TEST_2','human_1':'A','human_2':'A'}])
    def test_duplicate_human_ids_are_rejected(self):
        with self.assertRaises(ValueError):score([{'id':'TEST','human_1':'A','human_2':'A'}]*2)

if __name__=='__main__':unittest.main()
