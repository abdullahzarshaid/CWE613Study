import unittest
import measurement as r
class PublicTests(unittest.TestCase):
    def setUp(self):self.rows=r.read('ANNOTATIONS_609.json')
    def test_no_copied_prose(self):
        for x in self.rows:self.assertFalse({'quote','reason','description','nvd_text'} & set(x))
    def test_complete_identifiers(self):self.assertEqual(len({x['id'] for x in self.rows}),609)
    def test_frozen_counts_and_bounds(self):
        x=r.calculate(self.rows,r.read('AUDIT_LABELS_120.json'),r.read('BALANCED_60.json'),r.read('NEIGHBOR_236.json'))
        self.assertEqual(x['class_counts']['v2']['A'],134);self.assertEqual(x['bounds']['AB']['lower'],228)
    def test_audit_exposed(self):
        for x in r.read('AUDIT_LABELS_120.json'):self.assertIn('exposed',str(x['reader_kind']).lower())
    def test_balanced_missing_not_unchanged(self):
        self.assertEqual(sum(x['enriched_class'] is None for x in r.read('BALANCED_60.json')),18)
    def test_archive_not_semantic_census(self):self.assertEqual(len(r.read('ARCHIVE_611_IDS.json')),611)

    def test_exact_duplicate_sensitivity(self):
        import export_results
        result=export_results.generate()
        d=result['exact_duplicate_sensitivity']
        self.assertEqual((d['collapsed_n'],d['duplicate_groups'],d['duplicate_records']),(598,2,13))
        self.assertAlmostEqual(d['AB_pct'],46.82274247491639)

    def test_structured_dimension_counts(self):
        from collections import Counter
        events=Counter(e.get('event') for r in self.rows for e in r.get('events',[]) if isinstance(e,dict))
        self.assertEqual(events['time-expiration'],155)
        self.assertEqual(events['logout'],146)
        self.assertEqual(events['password-change'],74)
        self.assertEqual(sum(r.get('operation')=='unknown' for r in self.rows),160)
        self.assertEqual(sum(r.get('object_role')=='authority-credential' for r in self.rows),458)

if __name__=='__main__':unittest.main()
