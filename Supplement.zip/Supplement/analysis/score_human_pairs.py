#!/usr/bin/env python3
"""Score supplied paired human labels. Never populate, infer or adjudicate ratings."""
from pathlib import Path
from collections import Counter
import argparse, csv, hashlib, json
CLASSES=tuple('ABTIO')

def score(rows):
    if len(rows)<2: raise ValueError('At least two complete, genuinely paired ratings are required.')
    ids=[r['id'].strip() for r in rows]
    if not all(ids) or len(ids)!=len(set(ids)): raise ValueError('Missing or duplicate record IDs.')
    for r in rows:
        if r.get('human_1') not in CLASSES or r.get('human_2') not in CLASSES:
            raise ValueError('Both human_1 and human_2 must contain an actual A/B/T/I/O rating for each record.')
    n=len(rows);matrix={a:{b:0 for b in CLASSES} for a in CLASSES}
    for r in rows: matrix[r['human_1']][r['human_2']]+=1
    n1=Counter(r['human_1'] for r in rows);n2=Counter(r['human_2'] for r in rows)
    agree=sum(matrix[c][c] for c in CLASSES);po=agree/n
    pe=sum(n1[c]*n2[c] for c in CLASSES)/(n*n)
    pooled=n1+n2;M=2*n;de=(M*M-sum(v*v for v in pooled.values()))/(M*(M-1))
    return {'n_pairs':n,'agreements':agree,'raw_agreement':po,'cohen_kappa':None if pe==1 else (po-pe)/(1-pe),
            'krippendorff_alpha_nominal':None if de==0 else 1-(1-po)/de,
            'confusion_matrix_human1_rows_human2_columns':matrix,
            'disagreements':[{'id':r['id'],'human_1':r['human_1'],'human_2':r['human_2']} for r in rows if r['human_1']!=r['human_2']],
            'interpretation':'Agreement on submitted paired labels. Independence, blinding and correctness are not established by these coefficients.'}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True,type=Path);p.add_argument('--out-dir',required=True,type=Path)
    a=p.parse_args()
    if not a.input.is_file(): p.error('Input file does not exist; handwritten ratings must be transcribed without inference.')
    with a.input.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    if not rows or not {'id','human_1','human_2'} <= set(rows[0]): p.error('Required CSV columns: id,human_1,human_2')
    try: result=score(rows)
    except ValueError as e: p.error(str(e))
    result['input_sha256']=hashlib.sha256(a.input.read_bytes()).hexdigest()
    a.out_dir.mkdir(parents=True,exist_ok=True)
    (a.out_dir/'human_agreement.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({k:result[k] for k in ['n_pairs','agreements','cohen_kappa','krippendorff_alpha_nominal']}))
if __name__=='__main__': main()
