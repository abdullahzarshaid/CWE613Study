"""Offline categorical reanalysis, deterministic figure generation and SessTrace."""
from pathlib import Path
from collections import Counter
import argparse, hashlib, json, subprocess, sys
ROOT=Path(__file__).resolve().parent.parent
FILES={'ANNOTATIONS_609.json': 'dataset/CWE613_annotations_609.json', 'API_IDS.json': 'dataset/api_ids.json', 'ARCHIVE_611_IDS.json': 'dataset/archive_611_ids.json', 'AUDIT_LABELS_120.json': 'consistency/labels_120.json', 'BALANCED_60.json': 'sources/balanced_60.json', 'NEIGHBOR_236.json': 'neighbours/records_236.json', 'CATALOGUE_41.json': 'catalogue/releases_41.json', 'CATALOGUE_CURRENT.json': 'catalogue/current_snapshot.json', 'CATALOGUE_MILESTONES.json': 'catalogue/milestones.json', 'MAPPING_EXAMPLES.json': 'catalogue/mapping_examples.json'}
CLASSES=list('ABTIO')
def read(name):return json.loads((ROOT/FILES.get(name,name)).read_text(encoding='utf-8'))
def dump(path,data):path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
def calculate(rows,audit,balanced,neighbors):
    assert len(rows)==609 and len({r['id'] for r in rows})==609
    counts={v:{c:sum(r[v+'_class']==c for r in rows) for c in CLASSES} for v in ['historical','v1','v2']}
    expected=[[150,154,106,92,107],[134,154,97,124,100],[134,146,93,134,102]]
    assert [list(counts[v].values()) for v in counts]==expected
    bounds={}
    for name,labels in [('A',{'A'}),('AB',{'A','B'}),('T',{'T'})]:
        opts=[{r['v2_class'],*r['alternatives']} for r in rows]
        bounds[name]={'lower':sum(x<=labels for x in opts),'upper':sum(bool(x&labels) for x in opts),'assigned':sum(r['v2_class'] in labels for r in rows)}
    assert [(bounds[k]['lower'],bounds[k]['upper']) for k in ['A','AB','T']]==[(98,167),(228,341),(72,150)]
    matrix={a:{b:0 for b in CLASSES} for a in CLASSES}
    for r in audit:matrix[r['v2']][r['first_pass']]+=1
    n=len(audit);same=sum(matrix[c][c] for c in CLASSES)
    pe=sum(sum(matrix[c].values())*sum(matrix[a][c] for a in CLASSES) for c in CLASSES)/n**2
    consistency={'n':n,'agreement':same/n,'kappa':(same/n-pe)/(1-pe),'matrix':matrix,'meaning':'Exposed model-assisted first-pass consistency; not accuracy or external validation.'}
    strata={}
    for c in CLASSES:
        sub=[r for r in balanced if r['historical_stratum']==c]
        ev=[r for r in sub if r['enriched_class'] is not None]
        changed=sum(r['enriched_class']!=r['nvd_class'] for r in ev)
        strata[c]={'selected':len(sub),'evaluable':len(ev),'changed':changed,'unchanged':len(ev)-changed,'unevaluable':len(sub)-len(ev)}
    assert sum(x['changed'] for x in strata.values())==9
    assert sum(x['evaluable'] for x in strata.values())==42
    neighbor={}
    for pop in ['672','384']:
        sub=[r for r in neighbors if r['population']==pop]
        neighbor[pop]={'n':len(sub),'counts':dict(Counter(r['tier'] for r in sub))}
    random384=[r for r in neighbors if r['population']=='384' and 'random' in r['selection']]
    neighbor['384_random']={'n':len(random384),'counts':dict(Counter(r['tier'] for r in random384))}
    assert neighbor['672']['n']==92 and neighbor['384']['n']==144
    cells={y:{g:Counter() for g in ['P-any','S-only']} for y in ['2021','2022','2023','2024']}
    for r in rows:
        y=r['published'][:4]
        if y in cells:cells[y][r['designation']][r['v2_class']]+=1
    window=sum(sum(v.values()) for ys in cells.values() for v in ys.values())
    standard={}
    for g in ['P-any','S-only']:
        ng=sum(sum(ys[g].values()) for ys in cells.values());ab=sum(ys[g]['A']+ys[g]['B'] for ys in cells.values())
        pct=sum(sum(sum(v.values()) for v in ys.values())/window*(ys[g]['A']+ys[g]['B'])/sum(ys[g].values()) for ys in cells.values())*100
        standard[g]={'n':ng,'ab':ab,'crude_pct':100*ab/ng,'year_standardized_pct':pct}
    evidence={}
    for c in 'AB':
        sub=[r for r in rows if r['v2_class']==c]
        evidence[c]={'n':len(sub),'post_event_access':dict(Counter(r['post_event_access'] for r in sub)),'operation':dict(Counter(r['operation'] for r in sub)),'scope_basis':dict(Counter(r['scope_basis'] for r in sub))}
        evidence[c]['joint_detail']=sum(r['post_event_access']=='reported' and r['operation']!='unknown' and r['scope_basis']!='unresolved' for r in sub)
        evidence[c]['reported_unknown_operation']=sum(r['post_event_access']=='reported' and r['operation']=='unknown' for r in sub)
    restrictions={}
    for key,sub in [('all',rows),('no_recorded_alternative',[r for r in rows if not r['alternatives']]),('operation_named',[r for r in rows if r['operation']!='unknown']),('scope_not_unresolved',[r for r in rows if r['scope_basis']!='unresolved'])]:
        nsub=len(sub);a=sum(r['v2_class']=='A' for r in sub);ab=sum(r['v2_class'] in ['A','B'] for r in sub)
        restrictions[key]={'n':nsub,'excluded':609-nsub,'A':a,'AB':ab,'A_pct':100*a/nsub,'AB_pct':100*ab/nsub}
    assert sum(d['joint_detail'] for d in evidence.values())==210
    return {'population':609,'class_counts':counts,'bounds':bounds,'v1_v2_transitions':dict(Counter(r['v1_class']+'->'+r['v2_class'] for r in rows)),'audit':consistency,'balanced':strata,'neighbors':neighbor,'year_2021_2024':standard,'evidence_detail':evidence,'evidence_restrictions':restrictions}
def figures(result,history,out):
    """Compatibility entry point; canonical figure design lives in figure_factory."""
    from figure_factory import create
    return create(result,out)
