"""Release-maintenance command. Run after an intentional, reviewed source change.
Ordinary reproduction never updates expected outputs or regenerates these hashes.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
EXCLUDE_DIRS={'build','__pycache__','.git','.pytest_cache','generated_figures'}
EXCLUDE_SUFFIXES={'.pyc','.aux','.log','.blg','.out','.toc','.fls','.fdb_latexmk','.gz'}

def included(p):
    rel=p.relative_to(ROOT)
    if any(x in EXCLUDE_DIRS for x in rel.parts):return False
    if len(rel.parts)>1 and rel.parts[0]=='sesstrace' and rel.parts[1]=='generated':return False
    if p.name in {'Checksums.json','Checksums.txt'}:return False
    if p.suffix.lower() in EXCLUDE_SUFFIXES:return False
    return True

def make():
    h={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob('*')) if p.is_file() and included(p)}
    (ROOT/'checks').mkdir(exist_ok=True)
    (ROOT/'checks/Checksums.json').write_text(json.dumps(h,indent=2)+'\n',encoding='utf-8',newline='\n')
    (ROOT/'checks/Checksums.txt').write_text(''.join(f'{v}  {k}\n' for k,v in h.items()),encoding='utf-8',newline='\n')
    print('Recorded',len(h),'frozen file hashes')
if __name__=='__main__':make()
