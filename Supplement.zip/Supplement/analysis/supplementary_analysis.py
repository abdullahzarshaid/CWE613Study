"""Deterministic reporting views; never recode frozen CVEs or infer absent evidence."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import measurement as m

B_EVENTS = {
    'B1_password': {'password-change', 'password-reset'},
    'B2_account': {'account-disable', 'account-delete'},
    'B3_privilege': {'privilege-removal'},
    'B4_factor': {'mfa-change', 'factor-change', 'authentication-factor-change'},
    'B5_recovery': {'recovery-token-use', 'recovery-token-reuse', 'password-reset-token-use'},
}

def compute():
    rows = m.read('ANNOTATIONS_609.json')
    sources = {r['id']: r for r in m.read('dataset/source_records_609.json')}
    balanced = m.read('BALANCED_60.json')
    axes, event_objects, event_ops, b_profiles = [], Counter(), Counter(), Counter()
    object_roles = sorted({r['object_role'] for r in rows})
    event_records = Counter()
    for r in rows:
        events = sorted({e['event'] for e in r['events']})
        for event in events:
            event_records[event] += 1
            event_objects[event, r['object_role']] += 1
            event_ops[event, r['operation']] += 1
        # Options are alternatives, not simultaneously verified mechanisms.
        options = sorted({r['v2_class'], *r['alternatives']}, key=m.CLASSES.index)
        axes.append({
            'id': r['id'], 'summary_class': r['v2_class'],
            'mechanism_summary': None if r['v2_class']=='I' else r['v2_class'],
            'classification_status': 'unresolved' if r['v2_class']=='I' else 'assigned',
            'recorded_mechanism_candidates': [c for c in options if c!='I'],
            'recorded_summary_alternatives': list(r['alternatives']),
            'has_recorded_alternative': bool(r['alternatives']),
            'A_status': 'assigned' if r['v2_class']=='A' else 'alternative' if 'A' in r['alternatives'] else 'not_assessed_as_coexisting',
            'B_status': 'assigned' if r['v2_class']=='B' else 'alternative' if 'B' in r['alternatives'] else 'not_assessed_as_coexisting',
            'T_status': 'assigned' if r['v2_class']=='T' else 'alternative' if 'T' in r['alternatives'] else 'not_assessed_as_coexisting',
            'event_mentions': events, 'event_roles': r['events'],
            'object_role': r['object_role'], 'operation': r['operation'],
            'post_event_access': r['post_event_access'], 'scope_basis': r['scope_basis'],
            'source_sha256': r['source_sha256'],
            'derivation': 'Lossless reporting view of V2; no independent recoding.'})
        if r['v2_class']=='B':
            b_profiles.update(events)
    status_cells = Counter((r['designation'], sources[r['id']]['vulnStatus']) for r in rows)
    source_missing = []
    for dimension in ('historical_stratum','v1_class','publication_year','designation','sourceIdentifier'):
        cells = defaultdict(Counter)
        for b in balanced:
            r = next(r for r in rows if r['id']==b['id'])
            group = b['historical_stratum'] if dimension=='historical_stratum' else b['nvd_class'] if dimension=='v1_class' else r['published'][:4] if dimension=='publication_year' else r['designation'] if dimension=='designation' else sources[b['id']]['sourceIdentifier']
            outcome = 'unevaluable' if b['enriched_class'] is None else 'changed' if b['enriched_class']!=b['nvd_class'] else 'unchanged'
            cells[group][outcome] += 1
        for group,c in sorted(cells.items()):
            source_missing.append({'dimension':dimension,'group':group,'selected':sum(c.values()),'evaluable':c['changed']+c['unchanged'],'changed':c['changed'],'unchanged':c['unchanged'],'unevaluable':c['unevaluable']})
    co = Counter()
    for r in rows:
        values = {d['value'] for w in sources[r['id']]['weaknesses'] for d in w['description'] if d['value'].startswith('CWE-') and d['value']!='CWE-613'}
        for value in values: co[value,r['v2_class']] += 1
    co_rows = [{'co_cwe':c,'n':sum(co[c,k] for k in m.CLASSES),**{k:co[c,k] for k in m.CLASSES}} for c in sorted({c for c,k in co}, key=lambda c:(-sum(co[c,k] for k in m.CLASSES), c))]
    ev_rows=[]
    for c in 'AB':
        counts=Counter((r['post_event_access'], 'named' if r['operation']!='unknown' else 'unknown', 'resolved' if r['scope_basis']!='unresolved' else 'unresolved') for r in rows if r['v2_class']==c)
        ev_rows += [{'class':c,'persistence':k[0],'operation':k[1],'scope':k[2],'n':n} for k,n in sorted(counts.items())]
    audit = m.read('AUDIT_LABELS_120.json')
    n=len(audit);p=sum(x['v2']==x['first_pass'] for x in audit)/n;z=1.959963984540054
    denom=1+z*z/n;center=(p+z*z/(2*n))/denom;half=z*((p*(1-p)/n+z*z/(4*n*n))**.5)/denom
    return {
        'record_axes':axes,
        'event_object_cells':[{'event':e,'object_role':o,'n':event_objects[e,o]} for e in sorted(event_records) for o in object_roles],
        'event_operation_cells':[{'event':e,'operation':o,'n':n} for (e,o),n in sorted(event_ops.items())],
        'b_event_mentions':[{'event':e,'n':n,'denominator':146} for e,n in b_profiles.most_common()],
        'status_designation':[{'designation':d,'status':s,'n':n} for (d,s),n in sorted(status_cells.items())],
        'source_missingness':source_missing,
        'co_cwe':co_rows,
        'evidence_partition':ev_rows,
        'repeat_agreement_wilson':{'n':n,'agreement':p,'lower':center-half,'upper':center+half,'method':'Wilson 95% reference interval, no finite-population correction; not human-human accuracy.'},
        'event_record_counts':dict(event_records),
        'event_count_units':[{'event':e,'event_annotations':sum(z['event']==e for r in rows for z in r['events']),'distinct_records':n} for e,n in sorted(event_records.items())],
    }

def write(out_root: Path):
    from export_results import table, dump
    x=compute(); dest=out_root/'outputs/supplementary'
    for k in ['record_axes','event_object_cells','event_operation_cells','b_event_mentions','status_designation','source_missingness','co_cwe','evidence_partition','event_count_units']:
        dump(dest/(k+'.json'),x[k]);table(dest/(k+'.csv'),x[k])
    dump(dest/'repeat_agreement_wilson.json',x['repeat_agreement_wilson'])
    return x

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out-dir',type=Path,default=m.ROOT/'build/reproduction');a=p.parse_args();write(a.out_dir)
