"""Regenerate figure assets separately from frozen manuscript assets."""
from pathlib import Path
import argparse
import measurement as m
from export_results import generate
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out-dir',type=Path,default=m.ROOT/'build/figures');a=p.parse_args()
    a.out_dir.mkdir(parents=True,exist_ok=True)
    m.figures(generate(),m.read('CATALOGUE_41.json'),a.out_dir)
