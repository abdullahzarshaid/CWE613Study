"""Scientific input, navigation and package-integrity checks.

These tests do not depend on editorial histories, author biographies or old QA
narratives. Synthetic test inputs are not research observations.
"""
from pathlib import Path
import csv
import hashlib
import json
import random
import re
import unittest

import measurement as m
import release_manifest

ROOT = m.ROOT


class PackageTests(unittest.TestCase):
    def test_retained_primary_inputs_match(self):
        expected = json.loads((ROOT / 'checks/Inputs.json').read_text())
        self.assertEqual(len(expected), 51)
        for name, digest in expected.items():
            with self.subTest(file=name):
                self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(), digest)

    def test_reference_inventory_is_complete(self):
        paths = json.loads((ROOT / 'checks/Outputs.json').read_text())
        self.assertEqual(len(paths), 61)
        self.assertEqual(paths, sorted(set(paths)))
        for name in paths:
            self.assertTrue((ROOT/name).is_file(), name)

    def test_retained_stratified_sample(self):
        rows = m.read('ANNOTATIONS_609.json')
        selected = m.read('BALANCED_60.json')
        rng = random.Random(2026091701)
        for label in 'ABTIO':
            pool = sorted(r['id'] for r in rows if r['historical_class'] == label)
            self.assertEqual(set(rng.sample(pool, 12)),
                {r['id'] for r in selected if r['historical_stratum'] == label})

    def test_actual_b_to_o_cases(self):
        actual = {r['id'] for r in m.read('ANNOTATIONS_609.json')
                  if r['v1_class'] == 'B' and r['v2_class'] == 'O'}
        self.assertEqual(actual, {'CVE-2019-1003049', 'CVE-2024-20301',
            'CVE-2024-32006', 'CVE-2025-61775', 'CVE-2026-41916'})

    def test_equations_preserved(self):
        text = (ROOT/'manuscript/paper.tex').read_text()
        actual = re.findall(r'\\begin\{equation\}.*?\\end\{equation\}', text, re.S)
        expected = json.loads((ROOT/'checks/Equations.json').read_text())
        self.assertEqual(actual, expected)
        self.assertEqual(len(actual), 3)
        self.assertIn(r'\kappa', actual[0])
        self.assertIn(r'\neg', actual[1])
        self.assertIn(r'\neg', actual[2])

    def test_reference_coverage_and_order(self):
        text = (ROOT/'manuscript/paper.tex').read_text()
        bib = (ROOT/'manuscript/references.bib').read_text()
        keys = re.findall(r'@\w+\{([^,]+),', bib)
        cited = [k for group in re.findall(r'\\cite\{([^}]+)\}', text)
                 for k in group.split(',')]
        order = re.findall(r'\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}',
                            (ROOT/'manuscript/paper.bbl').read_text())
        self.assertEqual(len(keys), 49)
        self.assertEqual(len(keys), len(set(keys)))
        self.assertEqual(set(keys), set(cited))
        self.assertEqual(list(dict.fromkeys(cited)), order)

    def test_record_change_links_resolve(self):
        with (ROOT/'classifications/v1_v2_record_changes.csv').open(newline='') as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 17)
        for row in rows:
            for column in ['v1_evidence', 'v2_evidence']:
                path, record_id = row[column].split('#', 1)
                self.assertEqual(record_id, row['id'])
                records = json.loads((ROOT/path).read_text())
                entry = next(r for r in records if r['id'] == record_id)
                self.assertEqual(entry['class'], row[column[:2]+'_class'])

    def test_reviewer_entrypoints(self):
        for path in ['Readme.txt', 'Methods.txt', 'dataset/Codebook.txt',
                     'dataset/DataDictionary.txt', 'evidence/Rights.txt',
                     'evidence/EvidenceMap.txt', 'consistency/Scoring.txt',
                     'manuscript/Paper.pdf']:
            self.assertTrue((ROOT/path).is_file(), path)
        rootfiles = [p.name for p in ROOT.iterdir() if p.is_file()]
        self.assertEqual(sorted(rootfiles), ['Methods.txt', 'Readme.txt'])

    def test_no_editorial_payload_or_font_binaries(self):
        for path in ROOT.rglob('*'):
            if not path.is_file() or not release_manifest.included(path):
                continue
            self.assertNotIn(path.suffix.lower(), {'.md', '.pfb', '.pfa', '.ttf', '.otf', '.woff', '.woff2'})
            self.assertFalse(path.name.startswith(('LANGUAGE_', 'FINAL_QA_', 'AUTHOR_BIOGRAPHIES')))
        self.assertFalse((ROOT/'review').exists())
        self.assertFalse((ROOT/'qa').exists())

    def test_release_manifest_covers_frozen_files(self):
        expected = json.loads((ROOT/'checks/Checksums.json').read_text())
        actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
                  if p.is_file() and release_manifest.included(p)}
        self.assertEqual(actual, set(expected))
        for path, digest in expected.items():
            self.assertEqual(hashlib.sha256((ROOT/path).read_bytes()).hexdigest(), digest)


if __name__ == '__main__':
    unittest.main()
