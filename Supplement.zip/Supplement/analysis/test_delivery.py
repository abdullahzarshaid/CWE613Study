import csv, json, unittest
from collections import Counter
import measurement as m
class DeliveryTests(unittest.TestCase):
    def csv(self,name):
        with (m.ROOT/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
    def test_csv_projection(self):
        rows=self.csv('dataset/CWE613_population_609.csv');original={r['id']:r for r in m.read('ANNOTATIONS_609.json')}
        self.assertEqual(len(rows),609)
        for r in rows:
            a=original[r['id']]
            for k in ['historical_class','v1_class','v2_class','source_sha256','operation','scope_basis']:self.assertEqual(r[k],a[k])
    def test_versions(self):
        for name,counts in [('historical_labels.csv',[150,154,106,92,107]),('v1_uniform_labels.csv',[134,154,97,124,100]),('v2_reviewed_labels.csv',[134,146,93,134,102])]:self.assertEqual(Counter(r['class'] for r in self.csv('classifications/'+name)),dict(zip(m.CLASSES,counts)))
    def test_alternatives(self):self.assertEqual(len(self.csv('classifications/alternative_interpretations.csv')),206)
    def test_source_attempts(self):self.assertEqual(len(self.csv('sources/source_locator_table.csv')),97)
    def test_balanced_outcomes(self):self.assertEqual(Counter(r['outcome'] for r in self.csv('sources/balanced_60_results.csv')),{'unchanged':33,'changed':9,'unevaluable':18})
    def test_consistency_disagreements(self):self.assertEqual({r['id'] for r in self.csv('consistency/disagreements.csv')},{'CVE-2020-27739','CVE-2016-6545'})
    def test_neighbor_sets(self):
        for name,n in [('CWE672_92.csv',92),('CWE384_random60.csv',60),('CWE384_screened_union144.csv',144)]:self.assertEqual(len(self.csv('neighbours/'+name)),n)
    def test_figures_match_manuscript(self):
        for p in (m.ROOT/'manuscript/figures').glob('*.pdf'):self.assertEqual(p.read_bytes(),(m.ROOT/'outputs/figures'/p.name).read_bytes())
if __name__=='__main__':unittest.main()
