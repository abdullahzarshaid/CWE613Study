"""Verify the frozen release, regenerate into build/, run contracts and reverify."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'analysis'))
from export_results import generate,require
import measurement as m

def verify():
    p=ROOT/'checks/Checksums.json';require(p.is_file(),'Missing release hash manifest')
    hashes=json.loads(p.read_text(encoding='utf-8'))
    for name,digest in hashes.items():
        q=(ROOT/name).resolve();require(q.is_relative_to(ROOT.resolve()),'Unsafe manifest path')
        require(q.is_file() and hashlib.sha256(q.read_bytes()).hexdigest()==digest,'Hash mismatch: '+name)
    print('Verified',len(hashes),'frozen file hashes',flush=True);return hashes

def run(args,cwd=ROOT):
    subprocess.run(args,cwd=cwd,check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','MPLBACKEND':'Agg'})

def scientific(obj):
    obj=json.loads(json.dumps(obj));obj.pop('generated_at_utc',None);obj.pop('python',None)
    if isinstance(obj.get('summary'),dict):obj['summary'].pop('elapsed_s',None)
    return obj

def compare_lab(g,r):
    a=json.loads((g/'benchmark_results.json').read_text());b=json.loads((r/'benchmark_results.json').read_text())
    require(scientific(a)==scientific(b),'Withdrawal scientific results differ')
    for name in ['benchmark_matrix.csv','artifact_inventory.csv']:
        require((g/name).read_text()==(r/name).read_text(),'Withdrawal table differs: '+name)
    expected=sorted(p.name for p in (r/'traces').glob('*.json'))
    require(sorted(p.name for p in (g/'traces').glob('*.json'))==expected,'Trace file coverage differs')
    for name in expected:require(json.loads((g/'traces'/name).read_text())==json.loads((r/'traces'/name).read_text()),'Trace differs: '+name)
    return a

def main():
    p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--no-figures',action='store_true');p.add_argument('--no-tests',action='store_true');p.add_argument('--pdf',action='store_true');a=p.parse_args()
    hashes=verify()
    if a.verify_only:return
    out=ROOT/'build/reproduction';shutil.rmtree(out,ignore_errors=True)
    result=generate(out)
    reference_files=json.loads((ROOT/'checks/Outputs.json').read_text())
    produced=sorted(str(q.relative_to(out)).replace('\\','/') for q in out.rglob('*') if q.is_file())
    require(produced==reference_files,'Rebuilt file coverage differs from the reference manifest')
    for name in produced:
        require((out/name).read_bytes()==(ROOT/name).read_bytes(),'Rebuilt numerical/projection output differs: '+name)
    figure_count=0
    if not a.no_figures:
        from figure_factory import create,NAMES
        dest=ROOT/'build/figures';shutil.rmtree(dest,ignore_errors=True);create(result,dest)
        fresh=json.loads((dest/'FIGURE_DATA.json').read_text());frozen=json.loads((ROOT/'outputs/figures/FIGURE_DATA.json').read_text())
        # Renderer bytes can vary across plotting versions; source values cannot.
        for record in fresh:
            if isinstance(record,dict):record.pop('pdf_sha256',None)
        for record in frozen:
            if isinstance(record,dict):record.pop('pdf_sha256',None)
        require(fresh==frozen,'Figure source values/specifications differ')
        require(len(list(dest.glob('*.pdf')))==len(NAMES),'Missing regenerated figures');figure_count=len(NAMES)
    if not a.no_tests:
        run([sys.executable,'-m','unittest','discover','-s','analysis','-p','test_*.py','-v'])
        run([sys.executable,'-m','unittest','discover','-s','tests','-v'],ROOT/'sesstrace')
    withdrawal=ROOT/'build/withdrawal';shutil.rmtree(withdrawal,ignore_errors=True)
    run([sys.executable,'run_benchmark.py','--out-dir',str(withdrawal)],ROOT/'sesstrace')
    bench=compare_lab(withdrawal,ROOT/'sesstrace/results');require(bench['summary']['all_clean'],'Withdrawal contract failure')
    expiry=ROOT/'build/expiration';shutil.rmtree(expiry,ignore_errors=True)
    run([sys.executable,'sesstrace/expiry_witness.py','--out-dir',str(expiry)])
    ex=json.loads((expiry/'expiry_results.json').read_text());require(ex==json.loads((ROOT/'reference/expiration/expiry_results.json').read_text()),'Expiration reference mismatch')
    if a.pdf:
        from build_manuscript import build
        build()
    require(verify()==hashes,'Release manifest changed during reproduction')
    report={'status':'PASS','population':609,'supplied_all_year_id_count':611,'repeat_coding_n':120,'repeat_agreement':result['audit']['agreement'],'repeat_kappa':result['audit']['kappa'],'human_human_statistic':'not computed: actual paired human ratings are not supplied in this release','numerical_projection_files_compared':len(produced),'figures_regenerated':figure_count,'withdrawal':bench['summary'],'expiration':ex['summary'],'release_unchanged':True,'scope':'Reconstruction of supplied decisions and observations; not re-enumeration of absent raw feeds or independent human validation.'}
    report['withdrawal'].pop('elapsed_s',None)
    (ROOT/'build/REPRODUCTION_REPORT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
