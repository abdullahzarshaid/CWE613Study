"""Regression coverage for the four final audit corrections.

Build-path probes use temporary toy projects only. The successful-build unit
probe mocks TeX; real pdfLaTeX/BibTeX builds are separate release checks.
No synthetic rating is introduced into the research corpus.
"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import csv
import json
import re
import tempfile
import unittest

import build_manuscript as bm
import measurement as m
import supplementary_analysis as sa


class FinalAuditTests(unittest.TestCase):
    def _reject_overlap(self, relation):
        with tempfile.TemporaryDirectory(prefix="paper1_safe_path_") as td:
            project = Path(td) / "toy_project"
            source = project / "manuscript"
            source.mkdir(parents=True)
            sentinel = source / "paper.tex"
            sentinel.write_text("Temporary source sentinel.\n", encoding="utf-8")
            sibling = project / "preserve.txt"
            sibling.write_text("Temporary project sentinel.\n", encoding="utf-8")
            dest = {"equal": source, "descendant": source / "build",
                    "ancestor": project}[relation]
            with patch.object(bm.shutil, "rmtree", side_effect=AssertionError(
                    "No deletion may occur before overlap rejection")) as deletion:
                with self.assertRaisesRegex(ValueError, "must not overlap"):
                    bm.build(source, dest)
                deletion.assert_not_called()
            self.assertTrue(sentinel.is_file())
            self.assertTrue(sibling.is_file())

    def test_build_rejects_equal_destination(self):
        self._reject_overlap("equal")

    def test_build_rejects_descendant_destination(self):
        self._reject_overlap("descendant")

    def test_build_rejects_ancestor_destination(self):
        self._reject_overlap("ancestor")

    def test_build_rejects_ancestor_through_symlink(self):
        with tempfile.TemporaryDirectory(prefix="paper1_symlink_path_") as td:
            base = Path(td)
            project = base / "project"
            source = project / "manuscript"
            source.mkdir(parents=True)
            sentinel = source / "paper.tex"
            sentinel.write_text("Temporary source sentinel.\n", encoding="utf-8")
            alias = base / "alias"
            try:
                alias.symlink_to(project, target_is_directory=True)
            except (OSError, NotImplementedError):
                self.skipTest("Directory symlinks unavailable on this platform")
            with self.assertRaisesRegex(ValueError, "must not overlap"):
                bm.build(source, alias)
            self.assertTrue(sentinel.is_file())

    def test_build_permits_separate_sibling_directory(self):
        with tempfile.TemporaryDirectory(prefix="paper1_sibling_build_") as td:
            source = Path(td) / "manuscript"
            dest = Path(td) / "build"
            (source / "figures").mkdir(parents=True)
            (source / "paper.tex").write_text("Temporary source.\n", encoding="utf-8")
            (source / "figures/fixture.pdf").write_bytes(b"Temporary figure sentinel")
            def fake_run(command, **kwargs):
                cwd = Path(kwargs["cwd"])
                (cwd / "paper.log").write_text(
                    "Output written on paper.pdf (1 pages, 123 bytes).\n",
                    encoding="utf-8")
                (cwd / "paper.pdf").write_bytes(b"Temporary compiled sentinel")
                return SimpleNamespace(returncode=0, stdout="Mock build unit probe\n")
            with patch.object(bm.shutil, "which", side_effect=lambda n: "/mock/" + n), \
                 patch.object(bm.subprocess, "run", side_effect=fake_run), \
                 patch("builtins.print"):
                result = bm.build(source, dest)
            self.assertEqual(result["pages"], ["1"])
            self.assertTrue((source / "paper.tex").is_file())
            self.assertEqual((source / "figures/fixture.pdf").read_bytes(),
                             (dest / "figures/fixture.pdf").read_bytes())

    def test_full_alternative_arrays_preserved_for_every_record(self):
        original = {r["id"]: r for r in m.read("ANNOTATIONS_609.json")}
        axes = sa.compute()["record_axes"]
        self.assertEqual(len(axes), 609)
        for row in axes:
            with self.subTest(id=row["id"]):
                self.assertEqual(row["recorded_summary_alternatives"],
                                 original[row["id"]]["alternatives"])
                self.assertEqual(row["summary_class"], original[row["id"]]["v2_class"])

    def test_multiple_alternatives_including_unresolved_are_retained(self):
        axes = sa.compute()["record_axes"]
        selected = [r for r in axes if len(r["recorded_summary_alternatives"]) > 1
                    and "I" in r["recorded_summary_alternatives"]]
        self.assertEqual(len(selected), 8)
        case = next(r for r in selected if r["id"] == "CVE-2019-1003049")
        self.assertEqual(case["recorded_summary_alternatives"], ["B", "I"])
        self.assertEqual(case["summary_class"], "O")

    def test_frozen_json_and_csv_export_the_full_arrays(self):
        original = {r["id"]: r for r in m.read("ANNOTATIONS_609.json")}
        data = m.read("outputs/supplementary/record_axes.json")
        with (m.ROOT / "outputs/supplementary/record_axes.csv").open(
                encoding="utf-8", newline="") as stream:
            flat = list(csv.DictReader(stream))
        self.assertEqual(len(data), 609)
        self.assertEqual(len(flat), 609)
        for row in data:
            self.assertEqual(row["recorded_summary_alternatives"],
                             original[row["id"]]["alternatives"])
        for row in flat:
            self.assertEqual(json.loads(row["recorded_summary_alternatives"]),
                             original[row["id"]]["alternatives"])

    def test_documented_csv_paths_and_schemas_match(self):
        text = (m.ROOT / "dataset/DataDictionary.txt").read_text(encoding="utf-8")
        schemas = re.findall(r"^### ([^\n]+\.csv)\s*\n\s*Columns: ([^\n]+)",
                             text, flags=re.MULTILINE)
        self.assertGreaterEqual(len(schemas), 31)
        for relative, description in schemas:
            with self.subTest(path=relative):
                path = m.ROOT / relative
                self.assertTrue(path.is_file(), relative)
                expected = re.findall(r"`([^`]+)`", description)
                with path.open(encoding="utf-8", newline="") as stream:
                    self.assertEqual(next(csv.reader(stream)), expected)

    def test_reference_audit_numbers_match_final_bibliography(self):
        text = (m.ROOT / "manuscript/paper.bbl").read_text(encoding="utf-8")
        order = re.findall(r"\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}", text)
        with (m.ROOT / "evidence/ReferenceAudit.csv").open(
                encoding="utf-8", newline="") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(len(order), 49)
        self.assertEqual(len(rows), 49)
        self.assertEqual({r["bibkey"] for r in rows}, set(order))
        numbers = {key: i for i, key in enumerate(order, 1)}
        for row in rows:
            with self.subTest(key=row["bibkey"]):
                self.assertEqual(int(row["reference_number"]), numbers[row["bibkey"]])
        self.assertEqual(numbers["lee2023"], 11)
        self.assertEqual(numbers["meng2025slvhound"], 12)
        self.assertEqual(numbers["fett2017"], 13)


if __name__ == "__main__":
    unittest.main()
