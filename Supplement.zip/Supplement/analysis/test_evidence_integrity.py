"""Verify retained source evidence without assigning or adjudicating labels."""
import csv,hashlib,json,re,unittest
import measurement as m
def read(name):return json.loads((m.ROOT/name).read_text(encoding='utf-8'))
class EvidenceIntegrity(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.rows={r['id']:r for r in m.read('ANNOTATIONS_609.json')}
  cls.desc={r['id']:r for r in read('records/frozen_nvd_descriptions_609.json')}
 def test_all_609_source_hashes(self):
  self.assertEqual(set(self.rows),set(self.desc))
  for id,d in self.desc.items():self.assertEqual(hashlib.sha256(d['text'].encode()).hexdigest(),self.rows[id]['source_sha256'])
 def test_both_versions_exact_spans(self):
  for v in ['V1','V2']:
   records=read('records/'+v+'_evidence_decisions.json')
   self.assertEqual({r['id'] for r in records},set(self.rows))
   for r in records:
    text=self.desc[r['id']]['text'];span=r['supporting_span']
    self.assertEqual(text[span['start']:span['end']],span['quote'])
    for span in r['event_spans']:self.assertEqual(text[span['start']:span['end']],span['quote'])
    self.assertEqual(r['class'],self.rows[r['id']][v.lower()+'_class'])
 def test_v2_dimensions_preserved(self):
  for r in read('records/V2_evidence_decisions.json'):
   for k in ['object_role','operation','post_event_access','scope_basis']:self.assertEqual(r[k],self.rows[r['id']][k])
 def test_first_pass_evidence_and_normalization(self):
  records=read('records/consistency_evidence_120.json');audit={r['id']:r for r in m.read('AUDIT_LABELS_120.json')}
  self.assertEqual(len(records),120);self.assertEqual({r['id'] for r in records},set(audit))
  self.assertEqual(sum(r['excerpt_relation']=='whitespace-normalized' for r in records),3)
  for r in records:
   self.assertEqual(r['first_pass'],audit[r['id']]['first_pass'])
   s=r['supporting_span'];text=self.desc[r['id']]['text']
   self.assertEqual(text[s['start']:s['end']],s['quote'])
   self.assertEqual(' '.join(s['quote'].split()),' '.join(r['recorded_excerpt'].split()))
 def test_containers_and_source_roles(self):
  records=read('dataset/source_records_609.json');self.assertEqual({r['id'] for r in records},set(self.rows))
  for r in records:
   roles=[x['type'] for x in r['weaknesses'] if any(d['value']=='CWE-613' for d in x['description'])]
   self.assertTrue(roles)
   self.assertEqual('P-any' if 'Primary' in roles else 'S-only',self.rows[r['id']]['designation'])
   self.assertEqual(r['source_sha256'],self.rows[r['id']]['source_sha256'])
 def test_neighbor_source_coverage(self):
  src=read('records/neighbour_source_evidence_236.json');coded=m.read('NEIGHBOR_236.json')
  self.assertEqual(len(src),236)
  self.assertEqual({(r['id'],r['population']) for r in src},{(r['cve_id'],r['population']) for r in coded})
  for r in src:self.assertEqual(hashlib.sha256(r['text'].encode()).hexdigest(),r['sha256'])
 def test_record_changes(self):
  with (m.ROOT/'classifications/v1_v2_record_changes.csv').open(encoding='utf-8',newline='') as f:changes=list(csv.DictReader(f))
  self.assertEqual(len(changes),17)
  self.assertEqual({r['id'] for r in changes},{id for id,r in self.rows.items() if r['v1_class']!=r['v2_class']})
 def test_no_high_specificity_secret_markers(self):
  for folder in ['dataset','records','evidence']:
   for p in (m.ROOT/folder).rglob('*'):
    if p.suffix not in {'.json','.csv','.txt'}:continue
    t=p.read_text(encoding='utf-8-sig')
    self.assertIsNone(re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\b(?:sk-proj-|ghp_|github_pat_)[A-Za-z0-9_\-]{20,}',t),p.name)
if __name__=='__main__':unittest.main()
