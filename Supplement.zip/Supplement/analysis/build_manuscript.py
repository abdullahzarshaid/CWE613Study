"""Build the supplied LaTeX in an isolated directory, never in frozen manuscript/."""
from pathlib import Path
import argparse,json,os,re,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]

def build(source=None,destination=None):
    source=Path(source or ROOT/'manuscript').resolve()
    dest=Path(destination or ROOT/'build/pdf').resolve()
    if dest==source or dest.is_relative_to(source) or source.is_relative_to(dest):
        raise ValueError('Build and manuscript source directories must not overlap')
    if dest.exists():shutil.rmtree(dest)
    shutil.copytree(source,dest,ignore=shutil.ignore_patterns('*.aux','*.log','*.out','*.blg','*.pdf','*.synctex.gz'),dirs_exist_ok=True)
    # PDF figures are source assets; the generic output exclusion above must not remove them.
    for p in (source/'figures').glob('*.pdf'):
        (dest/'figures').mkdir(exist_ok=True);shutil.copy2(p,dest/'figures'/p.name)
    latex=shutil.which('pdflatex')
    bib=shutil.which('bibtex') or shutil.which('bibtex.original') or shutil.which('bibtex8')
    if not latex or not bib:raise RuntimeError('pdfLaTeX and BibTeX are required')
    commands=[[latex,'-halt-on-error','-interaction=nonstopmode','paper.tex'],[bib,'paper'],[latex,'-halt-on-error','-interaction=nonstopmode','paper.tex'],[latex,'-halt-on-error','-interaction=nonstopmode','paper.tex']]
    runs=[]
    for i,cmd in enumerate(commands):
        r=subprocess.run(cmd,cwd=dest,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'SOURCE_DATE_EPOCH':'1789689600','FORCE_SOURCE_DATE':'1'})
        (dest/f'build_step_{i+1}.txt').write_text(r.stdout,encoding='utf-8')
        runs.append({'command':[Path(cmd[0]).name,*cmd[1:]],'returncode':r.returncode})
        if r.returncode:raise RuntimeError(f'LaTeX build step {i+1} failed; inspect {dest}/build_step_{i+1}.txt')
    log=(dest/'paper.log').read_text(encoding='utf-8',errors='replace')
    warnings=[x for x in log.splitlines() if any(q in x for q in ['Warning:','Overfull \\hbox','Overfull \\vbox'])]
    unresolved=bool(re.search(r'(undefined references|Citation .* undefined|Reference .* undefined)',log,re.I))
    report={'commands':runs,'warnings':warnings,'unresolved_references':unresolved,'pages':re.findall(r'Output written on paper.pdf \((\d+) pages',log),'source_directory':str(source),'build_directory':str(dest)}
    (dest/'BUILD_REPORT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    if unresolved:raise RuntimeError('Unresolved manuscript references')
    print(json.dumps(report,indent=2));return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path);p.add_argument('--out-dir',type=Path);a=p.parse_args();build(a.source,a.out_dir)
