"""Rebuild deterministic projections into a separate output tree.

Default output: build/reproduction. Frozen evidence and reference outputs are
never modified. Release maintenance explicitly installs a reviewed output tree.
"""
from pathlib import Path
from collections import Counter
import csv, json, re
import measurement as m
ROOT=m.ROOT

def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')

def table(p,rows,keys=None):
    rows=list(rows);keys=keys or list(dict.fromkeys(k for r in rows for k in r))
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys,lineterminator='\n');w.writeheader()
        w.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()} for r in rows)

def require(ok,message):
    if not ok:raise ValueError(message)

def generate(out_root=None):
    out=Path(out_root) if out_root else ROOT/'build/reproduction'
    rows=m.read('ANNOTATIONS_609.json');audit=m.read('AUDIT_LABELS_120.json');balanced=m.read('BALANCED_60.json');neighbors=m.read('NEIGHBOR_236.json')
    result=m.calculate(rows,audit,balanced,neighbors)
    require(sum(bool(r['alternatives']) for r in rows)==206,'Alternatives')
    require(Counter(r['designation'] for r in rows)=={'P-any':240,'S-only':369},'Designation')
    archive=m.read('ARCHIVE_611_IDS.json');api=m.read('API_IDS.json');ids={r['id'] for r in rows}
    result['api']={'returned_rows':len(api),'unique':len(set(api)),'overlap':len(set(api)&ids),'overlap_pct':100*len(set(api)&ids)/609,
                   'duplicates':sorted(k for k,n in Counter(api).items() if n>1),'api_only':sorted(set(api)-ids),'feed_only':len(ids-set(api))}
    require((len(api),len(set(api)),len(set(api)&ids))==(263,261,254),'API ID-list observation')
    require(len(archive)==611 and set(archive)-ids=={'CVE-2013-0335','CVE-2014-3616'},'Supplied all-year ID list')
    history=m.read('CATALOGUE_41.json');result['catalogue']={'entries':len(history),'parsed':sum(x['parsed'] for x in history)}
    require(result['catalogue']=={'entries':41,'parsed':40},'Catalogue')
    result['archive_enumeration']=611
    result['archive_enumeration_scope']='Count of the supplied all-year identifier list; not a fresh enumeration of absent raw feeds.'
    result['alternative_records']=206;result['designation_counts']=dict(Counter(r['designation'] for r in rows))
    result['headline_percentages']={'A':100*134/609,'V1_AB':100*288/609,'V2_AB':100*280/609,'V2_AB_lifecycle':100*280/373}
    meta={r['id']:r for r in m.read('dataset/source_metadata.json')}
    full=[{**r,'publication_year':int(r['published'][:4]),'decision_version':'V2 post-collection model-assisted refinement','evidence_condition':'NVD-description-only',**{k:v for k,v in meta[r['id']].items() if k!='id'}} for r in rows]
    table(out/'dataset/CWE613_population_609.csv',full)
    for version,name in [('historical','historical_labels.csv'),('v1','v1_uniform_labels.csv'),('v2','v2_reviewed_labels.csv')]:
        table(out/'classifications'/name,({'id':r['id'],'class':r[version+'_class'],'version':version,'source_sha256':r['source_sha256']} for r in rows))
    table(out/'classifications/v1_v2_transitions.csv',({'V1':a,**{b:sum(r['v1_class']==a and r['v2_class']==b for r in rows) for b in m.CLASSES}} for a in m.CLASSES))
    table(out/'classifications/alternative_interpretations.csv',({'id':r['id'],'v2_class':r['v2_class'],'alternatives':r['alternatives']} for r in rows if r['alternatives']))
    years=sorted({int(r['published'][:4]) for r in rows})
    table(out/'dataset/publication_cohorts.csv',({'publication_year':y,'partial_year':y==2026,'n':sum(int(r['published'][:4])==y for r in rows)} for y in years))
    table(out/'dataset/year_designation_cells.csv',({'year':y,'designation':g,**{c:sum(r['published'][:4]==str(y) and r['designation']==g and r['v2_class']==c for r in rows) for c in m.CLASSES}} for y in range(2021,2025) for g in ['P-any','S-only']))
    table(out/'dataset/year_designation_all.csv',({'year':y,**{g:sum(r['published'][:4]==str(y) and r['designation']==g for r in rows) for g in ['P-any','S-only']}} for y in years))
    table(out/'sources/balanced_60_sample.csv',({'id':r['id'],'historical_stratum':r['historical_stratum'],'inclusion_probability':12/result['class_counts']['historical'][r['historical_stratum']],'seed':2026091701} for r in balanced))
    table(out/'sources/balanced_60_results.csv',({**r,'outcome':'unevaluable' if r['enriched_class'] is None else 'unchanged' if r['enriched_class']==r['nvd_class'] else 'changed'} for r in balanced))
    attempts=m.read('sources/source_attempts.json');require(len(attempts)==97,'Source attempts')
    table(out/'sources/source_locator_table.csv',attempts)
    table(out/'sources/source_status_summary.csv',({'status':k,'attempts':v} for k,v in sorted(Counter(r['status'] for r in attempts).items())))
    table(out/'consistency/fixed_120_sample.csv',({'id':r['id']} for r in audit))
    table(out/'consistency/v2_comparison.csv',audit)
    table(out/'consistency/disagreements.csv',(r for r in audit if r['first_pass']!=r['v2']))
    table(out/'consistency/confusion_matrix.csv',({'V2':a,**result['audit']['matrix'][a]} for a in m.CLASSES))
    dump(out/'consistency/agreement_results.json',result['audit'])
    for name,subset in [('CWE672_92.csv',[r for r in neighbors if r['population']=='672']),('CWE384_random60.csv',[r for r in neighbors if r['population']=='384' and 'random' in r['selection']]),('CWE384_screened_union144.csv',[r for r in neighbors if r['population']=='384'])]:table(out/'neighbours'/name,subset)
    table(out/'catalogue/catalogue_releases.csv',history)
    table(out/'catalogue/cwe613_history.csv',m.read('CATALOGUE_MILESTONES.json'))
    table(out/'catalogue/selected_mapping_events.csv',m.read('MAPPING_EXAMPLES.json'))
    t=out/'outputs/tables'
    table(t/'class_composition.csv',({'version':v,'n':609,**result['class_counts'][v]} for v in ['historical','v1','v2']))
    table(t/'year_standardization.csv',({'designation':g,**v} for g,v in result['year_2021_2024'].items()))
    table(t/'evidence_restrictions.csv',({'restriction':k,**v} for k,v in result['evidence_restrictions'].items()))
    table(t/'balanced_source_comparison.csv',({'historical_stratum':c,**v} for c,v in result['balanced'].items()))
    table(t/'sensitivity_bounds.csv',({'group':c,**v,'denominator':609} for c,v in result['bounds'].items()))
    table(t/'neighbor_summary.csv',({'set':c,'n':v['n'],**{k:v['counts'].get(k,0) for k in m.CLASSES}} for c,v in result['neighbors'].items()))
    table(t/'catalogue_summary.csv',[result['catalogue']])
    frozen=m.read('records/frozen_nvd_descriptions_609.json')
    by_id={r['id']:r for r in rows};groups={}
    for r in sorted(frozen,key=lambda r:r['id']):groups.setdefault(re.sub(r'\s+',' ',r['text']).strip().lower(),[]).append(r['id'])
    keep=[v[0] for v in groups.values()];dg=[v for v in groups.values() if len(v)>1];dc=Counter(by_id[i]['v2_class'] for i in keep)
    result['exact_duplicate_sensitivity']={'original_n':609,'collapsed_n':len(keep),'duplicate_groups':len(dg),'duplicate_records':sum(map(len,dg)),**{k:dc[k] for k in m.CLASSES},'AB_pct':100*(dc['A']+dc['B'])/len(keep)}
    table(t/'exact_duplicate_sensitivity.csv',[result['exact_duplicate_sensitivity']])
    table(t/'exact_duplicate_groups.csv',[{'representative':g[0],'members':g,'n':len(g),'rule':'lowercase whitespace-normalized exact English description'} for g in dg])
    import supplementary_analysis
    extra=supplementary_analysis.write(out)
    bench=m.read('sesstrace/results/benchmark_results.json');expiry=m.read('reference/expiration/expiry_results.json')
    result['laboratory']={'withdrawal':bench['summary'],'expiration':expiry['summary']}
    # Shipped withdrawal wall-time metadata is not a scientific result.
    result['laboratory']['withdrawal']={k:v for k,v in bench['summary'].items() if k!='elapsed_s'}
    gen=out/'manuscript/generated';gen.mkdir(parents=True,exist_ok=True)
    values={'Nrecords':609,'NstrictA':134,'NwithdrawalB':146,'NexpiryT':93,'Ninsufficient':134,'Nother':102,'NcombinedAB':280,'Nrepeat':120,'Nagree':118,'RepeatKappa':f"{result['audit']['kappa']:.4f}",'NwithdrawalSteps':bench['summary']['n_http_steps'],'NexpirySteps':expiry['summary']['n_http_steps'],'NallSteps':bench['summary']['n_http_steps']+expiry['summary']['n_http_steps']}
    (gen/'numbers.tex').write_text('% Generated by analysis/export_results.py; do not hand-edit.\n'+''.join('\\newcommand{\\%s}{%s}\n'%(k,v) for k,v in values.items()),encoding='utf-8',newline='\n')
    def tex(name,lines): (gen/name).write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
    tex('composition_rows.tex',[f"{label} & 609 & "+' & '.join(str(result['class_counts'][v][c]) for c in m.CLASSES)+r' \\' for v,label in [('historical','Historical'),('v1','Description-only V1'),('v2','Reviewed V2')]])
    tex('year_rows.tex',[f"{g} & {d['n']} & {d['crude_pct']:.2f} & {d['year_standardized_pct']:.2f}"+r' \\' for g,d in result['year_2021_2024'].items()])
    tex('restriction_rows.tex',[f"{label} & {d['n']} & {d['A_pct']:.2f} & {d['AB_pct']:.2f}"+r' \\' for k,label in [('all','Full V2'),('no_recorded_alternative','No recorded alternative'),('operation_named','Operation named'),('scope_not_unresolved','Scope basis recorded')] for d in [result['evidence_restrictions'][k]]])
    ep=extra['evidence_partition'];lookup={(r['class'],r['persistence'],r['operation'],r['scope']):r['n'] for r in ep}
    eporder=[('reported','named','resolved'),('reported','unknown','resolved'),('inferred','named','resolved'),('inferred','named','unresolved'),('inferred','unknown','resolved')]
    tex('evidence_rows.tex',[f"{p.title()} & {o.title()} & {'Recorded' if s=='resolved' else 'Unresolved'} & {lookup.get(('A',p,o,s),0)} & {lookup.get(('B',p,o,s),0)}"+r' \\' for p,o,s in eporder])
    tex('source_rows.tex',[f"{c} & {d['selected']} & {d['evaluable']} & {d['changed']} & {d['unevaluable']}"+r' \\' for c,d in result['balanced'].items()])
    names={'M1':'Local application logout','M2':'Resource-server access after logout','M3':'Refresh after token revocation','M4':'Federated logout at second relying party','M5':'Cached authorisation after revocation','M6':'Password change: other sessions'}
    lab=[]
    for b in bench['mechanisms']:
        lab.append({'id':b['id'],'class':b['paper_class'],'mechanism':names[b['id']],'vulnerable_status':b['vulnerable']['replay_status'],'fixed_status':b['fixed']['replay_status'],'steps':b['vulnerable']['n_http_steps']+b['fixed']['n_http_steps'],'controls_passed':6})
    for id,title in [('M7','Idle lifetime (renewed on successful access)'),('M8','Absolute lifetime (not renewed by access)')]:
        z=[r for r in expiry['scenarios'] if r['id']==id]
        lab.append({'id':id,'class':'T','mechanism':title,'vulnerable_status':z[0]['replay_status'],'fixed_status':z[1]['replay_status'],'steps':sum(r['n_http_steps'] for r in z),'controls_passed':sum(sum(r['controls'].values()) for r in z)})
    table(t/'laboratory_cases.csv',lab)
    tex('laboratory_rows.tex',[f"{r['id']} & {r['class']} & {r['mechanism']} & {r['vulnerable_status']} & {r['fixed_status']} & {r['steps']} & {r['controls_passed']}/6"+r' \\' for r in lab])
    dump(out/'outputs/RESULTS.json',result)
    return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out-dir',type=Path,default=ROOT/'build/reproduction');a=p.parse_args();generate(a.out_dir)
