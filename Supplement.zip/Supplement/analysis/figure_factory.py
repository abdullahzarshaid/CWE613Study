"""Publication-sized vector figures with checked diagram text boxes.

All quantitative panels use frozen records. Drawings distinguish sampling,
interpretation and experimental branches; no arrow implies an unperformed study.
"""
from pathlib import Path
import hashlib, json
import measurement as m

NAMES = ('figure0_study_pipeline','figure0_lifecycle_model','figure5_year_designation',
         'figure2_revision_flow','figure1_sensitivity','figure3_source_comparison',
         'figure6_event_object')

def create(result, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
    from supplementary_analysis import compute
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,
                        'axes.spines.top':False,'axes.spines.right':False,
                        'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,
                        'savefig.facecolor':'white'})
    ink='#24343e';edge='#516773';blue='#175f7a';pale='#eef3f6';gray='#e6e9ec'
    manifest=[];box_checks=[]
    def save(fig,name,source):
        fig.canvas.draw();renderer=fig.canvas.get_renderer()
        for item in getattr(fig,'_checked_boxes',[]):
            text,patch=item
            t=text.get_window_extent(renderer);b=patch.get_window_extent(renderer)
            okay=t.x0>=b.x0+2 and t.x1<=b.x1-2 and t.y0>=b.y0+1 and t.y1<=b.y1-1
            box_checks.append({'figure':name,'text':text.get_text(),'fits':bool(okay)})
            if not okay:raise ValueError(f'Diagram label exceeds its box: {name}: {text.get_text()}')
        fig.savefig(out/(name+'.pdf'),metadata={'CreationDate':None,'ModDate':None})
        fig.savefig(out/(name+'.png'),dpi=180)
        manifest.append({'name':name,'width_inches':fig.get_figwidth(),'height_inches':fig.get_figheight(),
                         'data':source,'pdf_sha256':hashlib.sha256((out/(name+'.pdf')).read_bytes()).hexdigest()})
        plt.close(fig)
    def diagram(w,h):
        fig=plt.figure(figsize=(w,h));ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off');fig._checked_boxes=[]
        return fig,ax
    def box(fig,ax,x,y,w,h,text,fs=9,fill=pale,bold=False):
        p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.003,rounding_size=0.008',
                        transform=ax.transAxes,facecolor=fill,edgecolor=edge,lw=.9)
        ax.add_patch(p);t=ax.text(x+w/2,y+h/2,text,transform=ax.transAxes,ha='center',va='center',
                                fontsize=fs,color=ink,linespacing=1.28,weight='bold' if bold else 'normal')
        fig._checked_boxes.append((t,p))
    def arrow(ax,start,end):
        ax.add_patch(FancyArrowPatch(start,end,transform=ax.transAxes,arrowstyle='-|>',mutation_scale=9,color=edge,lw=1))

    fig,ax=diagram(7.05,2.65)
    top=[('Frozen record population\n609 CWE-613 records\nEnglish NVD descriptions',.015),
         ('V1: common evidence condition\n609 description-only decisions\nHistorical labels withheld',.355),
         ('V2: reviewed interpretation\n17 class resolutions\nV1 retained for comparison',.695)]
    for text,x in top:box(fig,ax,x,.60,.287,.32,text,8.65,bold=False)
    arrow(ax,(.303,.76),(.350,.76));arrow(ax,(.643,.76),(.690,.76))
    bottom=[('Historical development labels\nDefine source-review strata;\nidentify V1 disagreements',.015),
            ('Source review: 60 selected\n12 from each historical class\nPaired baseline: V1',.355),
            ('Repeat-coding check: 120\nFirst pass compared with V2\nAuthor cross-check is separate',.695)]
    for text,x in bottom:box(fig,ax,x,.16,.287,.30,text,8.4,fill='#fafafa')
    # The historical layer is retained provenance, not an independent replication.
    for x in (.1585,.4985,.8385):arrow(ax,(x,.594),(x,.47))
    ax.text(.5,.055,'Neighbouring CWEs, catalogue history and the laboratory use separate supporting inputs.',ha='center',va='center',fontsize=8.15,color=ink)
    save(fig,'figure0_study_pipeline',{'population':609,'v1_v2_changes':17,'source_sample':60,'repeat_sample':120,'type':'conceptual_workflow'})

    fig,ax=diagram(7.05,3.12)
    box(fig,ax,.02,.76,.455,.20,'TIME-DRIVEN (T)\nLifetime or inactivity boundary is reached',8.8,fill='#f6f2e9',bold=True)
    box(fig,ax,.525,.76,.455,.20,'EVENT-DRIVEN (A / B)\nScoped logout, revocation or account change',8.8,bold=True)
    arrow(ax,(.245,.75),(.245,.685));arrow(ax,(.755,.75),(.755,.685))
    box(fig,ax,.02,.51,.96,.17,'Required basis: previously valid artifact + declared scope + applicable timing boundary',9,fill='#fafafa')
    arrow(ax,(.16,.505),(.16,.455))
    box(fig,ax,.02,.26,.28,.19,'Replay the previously valid\nartifact in the same scope',9)
    box(fig,ax,.36,.26,.28,.19,'Protected operation\nat enforcement point E1–E5',8.7)
    box(fig,ax,.70,.26,.28,.19,'ALLOW: scoped policy failure\nDENY: expected enforcement\nOther outcome: inconclusive',8.4,fill='#f6f2e9')
    arrow(ax,(.305,.355),(.352,.355));arrow(ax,(.645,.355),(.692,.355))
    box(fig,ax,.02,.025,.96,.155,'Record evidence separately: operation reported | persistence only | inference | unresolved.\nThe mechanism and the strength of its evidence are different fields.',8.65,fill='white')
    save(fig,'figure0_lifecycle_model',{'type':'conceptual_lifecycle','enforcement_points':['E1','E2','E3','E4','E5'],'outcome_requires_prior_access_scope_and_timing':True})

    rows=m.read('ANNOTATIONS_609.json');years=sorted({int(r['published'][:4]) for r in rows})
    p=[sum(r['published'][:4]==str(y) and r['designation']=='P-any' for r in rows) for y in years]
    s=[sum(r['published'][:4]==str(y) and r['designation']=='S-only' for r in rows) for y in years]
    fig,ax=plt.subplots(figsize=(3.43,2.60));fig.subplots_adjust(left=.15,right=.985,bottom=.23,top=.87)
    ax.bar(range(len(years)),p,color=blue,label='P-any',width=.73)
    ax.bar(range(len(years)),s,bottom=p,color='#bdc9cf',edgecolor='white',linewidth=.3,label='S-only',width=.73)
    ax.set_xticks(range(len(years)),[str(y) for y in years],rotation=45,ha='right')
    ax.set(ylabel='Records',ylim=(0,190));ax.legend(frameon=False,ncol=2,loc='upper left',bbox_to_anchor=(-.10,1.20),fontsize=8)
    ax.text(.99,1.12,'2026 partial',transform=ax.transAxes,ha='right',fontsize=8)
    save(fig,'figure5_year_designation',{'years':years,'P-any':p,'S-only':s})

    matrix=[[result['v1_v2_transitions'].get(a+'->'+b,0) for b in m.CLASSES] for a in m.CLASSES]
    fig,ax=plt.subplots(figsize=(3.43,2.98));fig.subplots_adjust(left=.22,right=.97,bottom=.20,top=.83)
    for i,a in enumerate(m.CLASSES):
        for j,b in enumerate(m.CLASSES):
            value=matrix[i][j];changed=i!=j and value>0
            ax.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor=blue if changed else gray if i==j else 'white',edgecolor='white',linewidth=1.5))
            ax.text(j,i,str(value) if value else '·',ha='center',va='center',fontsize=10,color='white' if changed else ink if value else '#b5b8ba',weight='bold' if value else 'normal')
    ax.set(xlim=(-.5,4.5),ylim=(4.5,-.5),xticks=range(5),yticks=range(5),xticklabels=m.CLASSES,yticklabels=m.CLASSES,xlabel='Reviewed class (V2)',ylabel='Baseline class (V1)')
    ax.tick_params(length=0);ax.set_aspect('equal');[sp.set_visible(False) for sp in ax.spines.values()]
    fig.text(.5,.94,'592 unchanged  |  17 revised',ha='center',fontsize=9.2,weight='bold')
    fig.text(.5,.045,'Shaded off-diagonal cells are class changes.',ha='center',fontsize=7.7)
    save(fig,'figure2_revision_flow',{'row_labels':m.CLASSES,'column_labels':m.CLASSES,'counts':matrix})

    fig,ax=plt.subplots(figsize=(3.43,2.42));fig.subplots_adjust(left=.16,right=.97,bottom=.23,top=.83)
    for y,k in enumerate(['A','AB','T']):
        b=result['bounds'][k];lo,hi,assigned=[100*b[q]/609 for q in ['lower','upper','assigned']]
        ax.plot([lo,hi],[y,y],color=blue,lw=3.5,solid_capstyle='butt');ax.plot(assigned,y,'o',color='black',ms=4)
        ax.text((lo+hi)/2,y-.22,f'{lo:.2f}–{hi:.2f}%',ha='center',va='bottom',fontsize=8)
    ax.set(yticks=range(3),yticklabels=['A','A+B','T'],ylim=(2.5,-.6),xlim=(0,65),xticks=[0,10,20,30,40,50,60],xlabel='Share of 609 records (%)')
    ax.axvline(50,lw=.8,ls=':',color='#89979e')
    fig.text(.5,.94,'Recorded alternatives, not confidence intervals',ha='center',fontsize=7.9)
    save(fig,'figure1_sensitivity',result['bounds'])

    fig,ax=plt.subplots(figsize=(3.43,2.70));fig.subplots_adjust(left=.14,right=.98,bottom=.21,top=.72)
    bottom=[0]*5
    for k,label,color in [('unchanged','Unchanged',blue),('changed','Changed','#7c8d73'),('unevaluable','Unavailable','#d1d6da')]:
        vals=[result['balanced'][c][k] for c in m.CLASSES]
        ax.bar(m.CLASSES,vals,bottom=bottom,color=color,label=label,width=.68)
        for i,n in enumerate(vals):
            if n:ax.text(i,bottom[i]+n/2,str(n),ha='center',va='center',fontsize=9,color='white' if k=='unchanged' else 'black')
        bottom=[a+b for a,b in zip(bottom,vals)]
    ax.set(ylim=(0,12.6),yticks=[0,3,6,9,12],ylabel='Selected records',xlabel='Historical sampling stratum')
    ax.legend(ncol=3,frameon=False,bbox_to_anchor=(.5,1.28),loc='upper center',fontsize=7.4,handlelength=1,columnspacing=.8)
    fig.text(.5,.94,'Unweighted sample: 12 records per stratum',ha='center',fontsize=8)
    save(fig,'figure3_source_comparison',result['balanced'])

    sup=compute();event_order=['time-expiration','logout','password-change','password-reset','account-disable','account-delete','privilege-removal','token-revocation']
    roles=['authority-credential','authorization-state','recovery-capability','termination-command','other','unknown']
    lookup={(r['event'],r['object_role']):r['n'] for r in sup['event_object_cells']}
    vals=np.array([[lookup.get((e,o),0) for o in roles] for e in event_order])
    # The actual data contain several rare object roles; 'Other' pools all remaining known roles.
    for i,e in enumerate(event_order):vals[i,4]=sum(r['n'] for r in sup['event_object_cells'] if r['event']==e and r['object_role'] not in {roles[j] for j in [0,1,2,3,5]})
    fig,ax=plt.subplots(figsize=(7.05,3.0));fig.subplots_adjust(left=.225,right=.99,bottom=.25,top=.94)
    from matplotlib.colors import LogNorm
    ax.imshow(vals+1,cmap='Blues',norm=LogNorm(vmin=1,vmax=max(2,int(vals.max())+1)),aspect='auto')
    for i in range(len(event_order)):
        for j in range(len(roles)):
            n=int(vals[i,j]);ax.text(j,i,str(n) if n else '·',ha='center',va='center',fontsize=8.8,color='white' if n>=30 else ink)
    ax.set_xticks(range(6),['Authority\ncredential','Authorization\nstate','Recovery\ncapability','Termination\ncommand','Other\nknown role','Unspecified'])
    ax.set_yticks(range(len(event_order)),[e.replace('-',' ') for e in event_order])
    ax.tick_params(length=0);[sp.set_visible(False) for sp in ax.spines.values()]
    fig.text(.62,.025,'Object role recorded in V2',ha='center',fontsize=9)
    save(fig,'figure6_event_object',{'events':event_order,'roles':roles,'counts':vals.tolist(),'unit':'Distinct CVE per event row; rows overlap','shading':'log(count+1); printed counts are authoritative'})
    (out/'FIGURE_DATA.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
    (out/'DIAGRAM_TEXT_QA.json').write_text(json.dumps(box_checks,indent=2)+'\n',encoding='utf-8',newline='\n')
    return manifest

if __name__=='__main__':
    import argparse
    from export_results import generate
    p=argparse.ArgumentParser();p.add_argument('--out-dir',type=Path,default=m.ROOT/'build/figures');a=p.parse_args()
    create(generate(),a.out_dir)
