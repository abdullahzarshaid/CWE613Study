#!/usr/bin/env python3
"""SessTrace benchmark: one command.

    python run_benchmark.py

Runs every mechanism (M1..M6) in its vulnerable and its fixed variant over real
HTTP on 127.0.0.1, evaluates the Proof-of-Vulnerability, Proof-of-Fix and
secure-negative checks, and writes:

    generated/benchmark_results.json  generated results object
    generated/benchmark_matrix.csv    one row per mechanism
    generated/traces/<M>_<variant>.json SessTrace lifecycle traces (secrets redacted)
    generated/artifact_inventory.csv  every artifact, where it was presented

Exit status 0 iff every PoV fails on vulnerable, every PoF passes on fixed and
the negative-control-failure count is zero. Python 3.10+, standard library only.
"""
import argparse
import os
import sys

if sys.version_info < (3, 10):
    sys.exit("SessTrace needs Python 3.10 or newer")

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from sesslab.runner import run  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default=os.path.join(HERE, "generated"),
                    help="Generated-output directory (default: sesstrace/generated). The frozen results/ directory is never overwritten by default.")
    args = ap.parse_args()
    results = run(HERE, os.path.abspath(args.out_dir))
    return 0 if results["summary"]["all_clean"] else 1


if __name__ == "__main__":
    sys.exit(main())
