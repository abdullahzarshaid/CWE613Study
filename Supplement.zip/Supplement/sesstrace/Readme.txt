# SessTrace 2.0 — scoped synthetic operational witnesses

This standard-library Python laboratory demonstrates six deliberately implemented lifecycle behaviours over HTTP on loopback. It is **not** a production scanner, a protocol-conformance suite, a collection of reproduced CVEs, or independent evidence that a new CWE is needed. No private-client data are included.

## Run

Python 3.10+ and four ephemeral loopback ports are required. No network installation or third-party Python library is needed.

```text
python -B run_benchmark.py
python -B -m unittest discover -s tests -v
```

The first command exits zero only if all six vulnerable witnesses succeed, all six fixed variants give contract-specific denials, and all negative controls work. The second exercises nominal and adversarial regression cases. Timing depends on the machine; the suite includes intentional local connection failures.

## Contract and outcomes

For the **declared synthetic policy**, a pre-event authority artifact should no longer complete its scoped protected operation after successful termination. The runner does not infer that every logout, password change or cached introspection response has identical obligations in real systems.

- `FAIL`: valid successful pre-event use and reported successful termination, followed by semantic completion of the protected operation. On an intentionally vulnerable variant this confirms its scoped PoV.
- `PASS`: valid scenario followed by the endpoint's expected semantic denial. On the fixed variant this confirms its scoped PoF.
- `INCONCLUSIVE`: failed/unknown precondition, unexpected/malformed response, wrong response principal, unsupported denial, transport failure, or unusable minted token. This never establishes either PoV or PoF.

HTTP 200 alone does not establish success. Profile/resource responses must contain the expected synthetic user and operation data. M3 must both mint a token and demonstrate that it can access the expected protected resource. Its denial must be HTTP 400 with `invalid_grant`; other HTTP 400 responses are inconclusive. Resource/profile denial must match its endpoint-specific error and HTTP 401, not merely any non-200 response.

The three controls are pre-event legitimate use, fresh login after the event, and continued access for unrelated user Bob. Failures are called `negative_control_failures`; **they are not a detector false-positive rate**. There are 36 nominal control checks across 12 scenarios.

`pof_confirmed` describes only the scoped replay invariant. Complete benchmark acceptance also requires successful legitimate-operation controls: use row `clean` and aggregate `all_clean`, not the PoF count alone. A fixed scenario with failing controls is not an accepted repair.

## Mechanisms and policy assumptions

| ID | Scoped demonstration | Boundary that must not be generalized |
|---|---|---|
| M1 | Copied RP1 session cookie replay after local logout | Local logout need not end other clients or independent grants |
| M2 | Access token replay after federated logout | Token revocation is an explicit laboratory policy, not an unconditional OIDC logout requirement |
| M3 | Refresh-token revocation followed by attempted token minting and resource use | Revocation response status alone does not establish which grant/token effects occurred |
| M4 | RP2 cookie replay after delivered back-channel logout | This synthetic receiver is not a standards-conformant OIDC implementation |
| M5 | Cached introspection acceptance after revocation | Laboratory policy requires next-request withdrawal; RFC 7662 permits policy-dependent caching trade-offs |
| M6 | Other-session access after a password change | Laboratory policy requires terminating other sessions; this is not a universal password-change requirement |

Six flags in a single codebase produce the vulnerable/fixed variants. These are fixture-defined expected behaviours, not externally adjudicated ground truth. M5's configured 300-second TTL is a design parameter, **not a measured 300-second residual duration**. The current suite tests immediate replay, not a longitudinal cache experiment.

## Trace schema 2.0

Every request has a `step`, `parent_step`, method, logical host, redacted path, status, artifact identifier and schema-filtered response. Nested calls record their actual initiating request as parent. The declared termination/replay `step` points to the initiating request; `completion_step` separately marks completion of nested calls. For M3, `witness_request_id` identifies the follow-up protected-resource request.

Output files:

- `generated/benchmark_results.json`: summaries, semantic outcomes and controls;
- `generated/benchmark_matrix.csv`: one row per mechanism;
- `generated/traces/*.json`: 12 detailed traces;
- `generated/artifact_inventory.csv`: synthetic artifacts and presentation steps.

Artifact values and prefixes are not exported. Free-text/nested response values, unknown field names and query values are redacted; only narrowly enumerated synthetic response literals and boolean fields remain. Regression tests use fabricated short/long canaries. This restricted synthetic exporter is **not certified to sanitize arbitrary real-world evidence**.

## Verification coverage

The original withdrawal suite tests twelve vulnerable/fixed scenarios across six mechanisms. M3 includes follow-up protected-resource witnesses after token issuance. Run the supplied command to regenerate the HTTP-step count.

Regression coverage includes initiating/nested request correlation, empty/malformed token and wrong-principal responses, unsupported denials, failed baseline/setup/termination, real local connection failure, structured transport errors, redaction canaries, minted-token resource usability and nominal PoV/PoF/control preservation.

## Limitations

The synthetic protocol omits TLS, PKCE and full JWT/issuer/audience/event validation. Never deploy it as an identity provider. Seeded identifiers are deliberately non-cryptographic laboratory values. Fixed handlers are fixed **for their named fixture**, not universally secure.

Only M1's repeat-seed trace equality is explicitly tested; do not claim complete wall-clock or multi-platform determinism. The laboratory uses real time and sequential scenarios. It does not evaluate races, propagation deadlines, all policy scopes, pure expiration, fixation or browser-cache-only boundary fixtures. Neighbour-CWE paths in metadata are explanatory hypotheses, not validated classifications of real cases.

Relevant standards:

- [RFC 7009, revocation](https://www.rfc-editor.org/rfc/rfc7009.html#section-2.1)
- [RFC 7662, introspection/caching](https://www.rfc-editor.org/rfc/rfc7662.html#section-4)
- [OWASP ASVS 5.0 V7.4.3](https://github.com/OWASP/ASVS/blob/v5.0.0_release/5.0/en/0x16-V7-Session-Management.md): an option to terminate other sessions, not a universal automatic-termination mandate.

## Frozen reference versus generated output

`results/` contains the frozen reference artifacts shipped with the paper. A normal benchmark run writes to `generated/` so that reproduction never overwrites the reference files. Runtime metadata (timestamp, interpreter version, elapsed time) is informative but is not used as a scientific equality criterion.

## Revision-added expiration module

See `Expiration.txt` and `expiry_witness.py` for separate M7/M8 idle and absolute expiration fixtures. They add four scenarios and 36 HTTP steps without overwriting the original M1–M6 reference. The combined revised-paper totals are eight mechanisms, sixteen scenarios and 399 steps.
