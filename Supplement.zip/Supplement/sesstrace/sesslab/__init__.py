"""SessTrace: a minimal, standard-library-only benchmark of explicit
session-termination failures (CWE-613 usage) exercised over real HTTP on
127.0.0.1.

Modules
  servers     the synthetic IdP / RP1 / RP2 / resource-server deployment, one
              documented flag per mechanism (vulnerable vs fixed)
  trace       the SessTrace lifecycle-trace recorder (redacting HTTP transcript)
  mechanisms  M1..M6: artifact set-up, protected operation, termination event
  runner      executes PoV / PoF / negative checks and writes results
"""
__version__ = "2.0.0"
