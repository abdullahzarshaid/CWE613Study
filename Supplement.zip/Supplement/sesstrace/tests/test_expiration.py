import unittest
import expiry_witness as e
class ExpirationWitnessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.results=e.run()
    def test_all_four_http_contracts(self):
        self.assertTrue(self.results['summary']['all_clean'])
        self.assertEqual(self.results['summary']['n_scenarios'],4)
        self.assertEqual(self.results['summary']['n_http_steps'],36)
        self.assertEqual(self.results['summary']['controls_passed'],12)
    def test_exact_boundaries(self):
        for r in self.results['scenarios']:
            self.assertEqual(r['boundary_s'],19 if r['mode']=='idle' else 10)
            self.assertEqual(r['replay_status'],401 if r['variant']=='fixed' else 200)
            self.assertEqual(r['paper_class'],'T')
    def test_idle_resets_absolute_does_not(self):
        for mode in ('idle','absolute'):
            f=e.Fixture(mode,True);token=f.login('alice');f.now=9;self.assertEqual(f.access(token)[0],200)
            f.now=10;self.assertEqual(f.access(token)[0],200 if mode=='idle' else 401)
    def test_missing_token_not_expiration(self):
        f=e.Fixture('absolute',True);f.now=100
        self.assertEqual(f.access('unknown'),(401,{'error':'missing_artifact'}))
    def test_repeatable_traces_and_no_serialized_credentials(self):
        import json
        again=e.run();self.assertEqual(again,self.results)
        text=json.dumps(again)
        self.assertNotIn('synthetic-alice',text);self.assertNotIn('Bearer ',text)
        self.assertNotIn('127.0.0.1',text)
if __name__=='__main__':unittest.main()
