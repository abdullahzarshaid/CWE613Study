"""Independent acceptance regression tests; no changes to canonical mechanisms."""
import unittest
from dataclasses import replace
from pathlib import Path
from sesslab.runner import replay_verdict, run_scenario
from sesslab.mechanisms import MECHANISMS, load_metadata, operation_outcome
from sesslab.trace import Response

class AcceptanceHardening(unittest.TestCase):
    def test_unexpected_responses_not_proof_of_fix(self):
        for mid in ['M1','M2','M3','M4','M5','M6']:
            for status in [None,201,204,302,404,500,503]:
                with self.subTest(mid=mid,status=status):
                    self.assertEqual(replay_verdict(mid,status),'INCONCLUSIVE')

    def test_contract_specific_denial(self):
        for mid in ['M1','M2','M3','M4','M5','M6']:
            # Status-only input, even expected HTTP status, is no longer sufficient.
            self.assertEqual(replay_verdict(mid,200),'INCONCLUSIVE')
            kind='refresh' if mid=='M3' else 'profile' if mid in {'M1','M4'} else 'resource'
            body='{"error":"invalid_grant"}' if mid=='M3' else '{"error":"no_session"}' if kind=='profile' else '{"error":"invalid_token"}'
            outcome=operation_outcome(Response(400 if mid=='M3' else 401,[],body),{'user':'alice'},kind)
            self.assertEqual(replay_verdict(mid,outcome),'PASS')

    def test_fault_injected_server_error(self):
        base=MECHANISMS[0]
        class Fault:
            id=base.id
            setup=base.setup
            terminate=base.terminate
            def operate(self,lab,ctx,actor):
                actual=base.operate(lab,ctx,actor)
                return replace(actual,status=500,success=False,denied=False,reason='unrecognized_response') if actor.startswith('attacker') else actual
        root=Path(__file__).resolve().parents[1]
        summary,trace=run_scenario(Fault(),'fixed',load_metadata(root)[base.id])
        self.assertEqual(summary['invariant'],'INCONCLUSIVE')
        self.assertFalse(summary['pof_confirmed'])
        self.assertIsNone(trace['replay']['residual_capability'])
        self.assertEqual(trace['cwe_rule_path']['classification'],'insufficient evidence')

if __name__=='__main__': unittest.main()
