"""Asserts the expected PASS/FAIL pattern of the SessTrace benchmark.

Run from the sesstrace/ directory:   python -m unittest
The benchmark is executed once (real HTTP on 127.0.0.1) into a temporary
directory; nothing under results/ is touched.
"""
import glob
import json
import os
import re
import shutil
import tempfile
import unittest

import sesslab
from sesslab.mechanisms import MECHANISMS, load_metadata
from sesslab.runner import run, run_scenario
from sesslab.servers import Flags

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(sesslab.__file__)))
SECRET_PATTERN = re.compile(r"[0-9a-f]{16,}|eyJ[A-Za-z0-9_-]{10,}")
EXPECTED_IDS = ["M1", "M2", "M3", "M4", "M5", "M6"]


class BenchmarkPattern(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix="sesstrace-")
        cls.results = run(ROOT, cls.tmp, quiet=True)
        cls.rows = {r["id"]: r for r in cls.results["mechanisms"]}

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_all_mechanisms_present(self):
        self.assertEqual(sorted(self.rows), EXPECTED_IDS)
        self.assertEqual(self.results["summary"]["n_scenarios"], 12)

    def test_pov_fails_invariant_on_every_vulnerable_variant(self):
        for mid in EXPECTED_IDS:
            v = self.rows[mid]["vulnerable"]
            with self.subTest(mechanism=mid):
                self.assertTrue(v["termination_reported_success"])
                self.assertEqual(v["replay_status"], 200)
                self.assertEqual(v["invariant"], "FAIL")
                self.assertTrue(v["pov_confirmed"])

    def test_pof_passes_invariant_on_every_fixed_variant(self):
        for mid in EXPECTED_IDS:
            f = self.rows[mid]["fixed"]
            with self.subTest(mechanism=mid):
                self.assertTrue(f["termination_reported_success"])
                self.assertNotEqual(f["replay_status"], 200)
                self.assertIn(f["replay_status"], (400, 401))
                self.assertEqual(f["invariant"], "PASS")
                self.assertTrue(f["pof_confirmed"])

    def test_zero_negative_control_failures(self):
        for mid in EXPECTED_IDS:
            for variant in ("vulnerable", "fixed"):
                s = self.rows[mid][variant]
                with self.subTest(mechanism=mid, variant=variant):
                    for name, n in s["negatives"].items():
                        self.assertTrue(n["pass"], "%s %s negative %s observed %s" % (mid, variant, name, n["observed"]))
                    self.assertEqual(s["negative_control_failures"], 0)
        self.assertEqual(self.results["summary"]["negative_control_failures"], 0)
        self.assertTrue(self.results["summary"]["all_clean"])

    def test_outputs_written(self):
        for name in ("benchmark_results.json", "benchmark_matrix.csv", "artifact_inventory.csv"):
            self.assertTrue(os.path.isfile(os.path.join(self.tmp, name)), name)
        traces = glob.glob(os.path.join(self.tmp, "traces", "*.json"))
        self.assertEqual(len(traces), 12)

    def test_traces_contain_required_fields_and_no_secrets(self):
        for path in glob.glob(os.path.join(self.tmp, "traces", "*.json")):
            with open(path, encoding="utf-8") as f:
                text = f.read()
            self.assertIsNone(SECRET_PATTERN.search(text), "secret-looking value in " + path)
            t = json.loads(text)
            for key in ("mechanism", "variant", "artifact_inventory", "termination", "steps",
                        "replay", "invariant", "cwe_rule_path", "uncertainty"):
                self.assertIn(key, t, path)
            self.assertIn(t["uncertainty"]["level"], ("low", "medium", "high"))
            self.assertTrue(t["termination"]["declared_expected_scope"])
            for step in t["steps"]:
                for key in ("step", "actor", "method", "host", "path", "status", "artifact_presented"):
                    self.assertIn(key, step)
            for a in t["artifact_inventory"]:
                for key in ("id", "type", "holder", "issued_at_step"):
                    self.assertIn(key, a)
            expected = "FAIL" if t["variant"] == "vulnerable" else "PASS"
            self.assertEqual(t["invariant"]["result"], expected, path)

    def test_declared_metadata_matches_code(self):
        meta = load_metadata(ROOT)
        self.assertEqual(sorted(meta), EXPECTED_IDS)
        self.assertEqual([m.id for m in MECHANISMS], EXPECTED_IDS)
        for mid in EXPECTED_IDS[:5]:
            self.assertEqual(meta[mid]["paper_class"], "A")
            self.assertEqual(meta[mid]["lifecycle_family"], "explicit_termination")
        self.assertEqual(meta["M6"]["paper_class"], "B")
        self.assertEqual(meta["M6"]["lifecycle_family"], "adjacent_withdrawal")

    def test_runtime_rule_path_respects_paper_class(self):
        meta = load_metadata(ROOT)
        by_id = {m.id: m for m in MECHANISMS}
        _, t1 = run_scenario(by_id["M1"], "vulnerable", meta["M1"])
        _, t6 = run_scenario(by_id["M6"], "vulnerable", meta["M6"])
        self.assertIn("paper class A", t1["cwe_rule_path"]["classification"])
        self.assertIn("paper class B", t6["cwe_rule_path"]["classification"])
        self.assertIn("adjacent-authority withdrawal", t6["cwe_rule_path"]["classification"])


class Determinism(unittest.TestCase):
    def test_same_seed_same_trace(self):
        meta = load_metadata(ROOT)
        mech = MECHANISMS[0]
        _, t1 = run_scenario(mech, "vulnerable", meta[mech.id])
        _, t2 = run_scenario(mech, "vulnerable", meta[mech.id])
        self.assertEqual(t1, t2)


class FlagsTest(unittest.TestCase):
    def test_unknown_flag_rejected(self):
        with self.assertRaises(ValueError):
            Flags(vulnerable={"M9"})

    def test_membership(self):
        self.assertIn("M3", Flags(vulnerable={"M3"}))
        self.assertNotIn("M3", Flags())


if __name__ == "__main__":
    unittest.main()
