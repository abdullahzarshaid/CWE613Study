"""Counterexamples found independently in v2; local-only regression gates."""
from dataclasses import replace
import json
from pathlib import Path
import socket
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from urllib.error import URLError
from sesslab.mechanisms import MECHANISMS, load_metadata, operation_outcome
from sesslab.runner import run_scenario, replay_verdict
from sesslab.trace import Response, Trace

ROOT = Path(__file__).resolve().parents[1]
META = load_metadata(ROOT)

class ResponseContracts(unittest.TestCase):
    def test_token_status_without_valid_payload_is_inconclusive(self):
        for body in ['{}','[]','null','<html>login</html>', '{"access_token":null}',
                     '{"access_token":""}', '{"access_token":"abc","token_type":"Other"}']:
            with self.subTest(body=body):
                o=operation_outcome(Response(200,[],body),{'user':'alice'},'refresh')
                self.assertEqual(replay_verdict('M3',o),'INCONCLUSIVE')

    def test_malformed_request_denials_not_revocation(self):
        for body in ['{}','{"error":"invalid_client"}','{"error":"unsupported_grant_type"}',
                     '{"error":"invalid_request"}','{"error":null}']:
            o=operation_outcome(Response(400,[],body),{'user':'alice'},'refresh')
            self.assertEqual(replay_verdict('M3',o),'INCONCLUSIVE')

    def test_wrong_principal_data_and_login_bodies_are_inconclusive(self):
        for kind,body in [('resource','{"sub":"bob","data":"report"}'),
                          ('resource','{"sub":"alice","data":"wrong"}'),
                          ('profile','{"sub":"alice","rp":"RP2"}'),
                          ('profile','{"logged_in":true}')]:
            o=operation_outcome(Response(200,[],body),{'user':'alice'},kind)
            self.assertFalse(o.success)
            self.assertEqual(replay_verdict('M1',o),'INCONCLUSIVE')

    def test_missing_artifact_denial_not_proof_of_fix(self):
        o=operation_outcome(Response(401,[],'{"error":"missing_token"}'),{'user':'alice'},'resource')
        self.assertEqual(replay_verdict('M2',o),'INCONCLUSIVE')

    def test_positive_response_contract(self):
        o=operation_outcome(Response(200,[],'{"sub":"alice","data":"report"}',request_id=5),{'user':'alice'},'resource')
        self.assertEqual(replay_verdict('M2',o),'FAIL')
        self.assertEqual(replay_verdict('M2',o,scenario_valid=False),'INCONCLUSIVE')

    def test_minted_but_unusable_token_not_residual_capability(self):
        responses=iter([Response(200,[],'{"access_token":"synthetic-invalid","token_type":"Bearer"}',request_id=1),
                        Response(401,[],'{"error":"invalid_token"}',request_id=2)])
        fake=SimpleNamespace(trace=SimpleNamespace(http=lambda *a,**k:next(responses),
                                                   register_artifact=lambda *a,**k:'A1'),
                             client=lambda rp:('a','b'),idp_url='http://unused',rs_url='http://unused')
        outcome=MECHANISMS[2].operate(fake,{'refresh':'test','user':'alice'},'alice')
        self.assertEqual(outcome.reason,'token_usability_unproven')
        self.assertEqual(replay_verdict('M3',outcome),'INCONCLUSIVE')

class ScenarioValidity(unittest.TestCase):
    def _fault(self, where):
        base=MECHANISMS[0]
        class Fault:
            id=base.id
            def setup(self,lab,user,actor):
                if where=='setup': raise ValueError('SYNTHETIC-SECRET-DO-NOT-LOG')
                return base.setup(lab,user,actor)
            def operate(self,lab,ctx,actor):
                value=base.operate(lab,ctx,actor)
                if where=='baseline' and lab.trace.phase=='pre_termination' and actor=='alice':
                    return replace(value,success=False,denied=False,reason='unrecognized_response')
                return value
            def terminate(self,lab,ctx,actor):
                value=base.terminate(lab,ctx,actor)
                if where=='termination': return Response(200,[],'{}',request_id=value.request_id)
                return value
        return run_scenario(Fault(),'vulnerable',META['M1'])

    def test_failed_baseline_never_classified(self):
        self._assert_invalid(*self._fault('baseline'))

    def test_failed_termination_never_classified(self):
        self._assert_invalid(*self._fault('termination'))

    def test_failed_setup_structured_and_no_exception_secret(self):
        s,t=self._fault('setup')
        self._assert_invalid(s,t)
        self.assertNotIn('SYNTHETIC-SECRET',json.dumps([s,t]))
        self.assertEqual(s['execution_error'],'ValueError')

    def _assert_invalid(self,s,t):
        self.assertFalse(s['scenario_valid'])
        self.assertFalse(s['pov_confirmed'])
        self.assertEqual(s['invariant'],'INCONCLUSIVE')
        self.assertIsNone(s['residual_capability'])
        self.assertEqual(t['cwe_rule_path']['classification'],'insufficient evidence')

class SafeTrace(unittest.TestCase):
    def test_free_text_nested_and_unknown_key_canaries_redacted(self):
        tr=Trace('M1','fixed',1)
        for canary in ['abc','SYNTHETIC-SECRET-123456']:
            body=json.dumps({'data':{'secret':canary},'error_description':canary,
                             canary:canary,'sub':canary,'ok':canary})
            self.assertNotIn(canary,json.dumps(tr._summarise_body(body)))
            self.assertNotIn(canary,json.dumps(tr._summarise_body(canary)))
            self.assertNotIn(canary,tr._redact_query('unknown='+canary))
            tr.register_artifact('cookie','alice',canary)
            self.assertNotIn(canary,json.dumps(tr.artifacts))

    def test_safe_literals_survive(self):
        tr=Trace('M1','fixed',1)
        self.assertEqual(tr._summarise_body('{"sub":"alice","data":"report","active":true}')['data'],'report')

    def test_transport_failure_structured_without_exception_text(self):
        tr=Trace('M1','fixed',1)
        with patch('sesslab.trace._OPENER.open',side_effect=URLError('SYNTHETIC-SECRET')):
            r=tr.http('GET','http://127.0.0.1:1/profile')
        self.assertIsNone(r.status)
        self.assertEqual(r.error,'URLError')
        self.assertNotIn('SYNTHETIC-SECRET',json.dumps(tr.steps))

    def test_actual_local_connection_failure(self):
        # Reserve but do not listen: guarantees this process is not probing another service.
        with socket.socket() as reserved:
            reserved.bind(('127.0.0.1',0))
            tr=Trace('M1','fixed',1)
            r=tr.http('GET','http://127.0.0.1:%s/profile' % reserved.getsockname()[1])
            self.assertIsNone(r.status)
            self.assertIsNotNone(r.error)

class TraceCorrelation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runs=[(m.id,variant,*run_scenario(m,variant,META[m.id]))
                  for m in MECHANISMS for variant in ('vulnerable','fixed')]

    def test_operation_pointers_are_actual_requests(self):
        for mid,variant,s,t in self.runs:
            with self.subTest(mid=mid,variant=variant):
                step=t['steps'][t['replay']['step']-1]
                expected='/token' if mid=='M3' else '/profile' if mid in {'M1','M4'} else '/api/data'
                self.assertEqual(step['path'],expected)
                self.assertEqual(step['status'],s['replay_status'])
                self.assertEqual(step['parent_step'],None)
                self.assertGreaterEqual(t['replay']['completion_step'],t['replay']['step'])
                term=t['steps'][t['termination']['step']-1]
                self.assertTrue(term['path'].startswith('/revoke' if mid in {'M3','M5'} else '/password' if mid=='M6' else '/logout'))
                self.assertIsNone(term['parent_step'])

    def test_nested_requests_have_causal_parent(self):
        for mid,variant,s,t in self.runs:
            for step in t['steps']:
                if step['path'] in {'/introspect','/backchannel_logout'}:
                    self.assertIsInstance(step['parent_step'],int)
                    self.assertLess(step['parent_step'],step['step'])

    def test_refresh_success_has_resource_witness(self):
        for mid,variant,s,t in self.runs:
            if mid=='M3' and variant=='vulnerable':
                witness=t['steps'][t['replay']['witness_request_id']-1]
                self.assertEqual(witness['path'],'/api/data')
                self.assertEqual(witness['response']['sub'],'alice')
                self.assertEqual(witness['status'],200)

    def test_nominal_patterns_and_renamed_metrics(self):
        for mid,variant,s,t in self.runs:
            self.assertEqual(s['invariant'],'FAIL' if variant=='vulnerable' else 'PASS')
            self.assertEqual(s['negative_control_failures'],0)
            self.assertNotIn('false_positives',s)
            self.assertEqual(t['schema'],'sesstrace-trace/2.0')

if __name__=='__main__': unittest.main()
