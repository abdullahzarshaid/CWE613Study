#!/usr/bin/env python3
"""Two revision-added HTTP expiration witnesses, separate from the original M1--M6.

A manually advanced clock makes the exact lifetime boundary reproducible without
sleeping. These are synthetic policy fixtures, not CVE reproductions.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import urlsplit, parse_qs
from threading import Thread
from pathlib import Path
import argparse, json

class Fixture:
    def __init__(self, mode, fixed, lifetime=10):
        if mode not in ('absolute','idle'): raise ValueError('Unknown expiration mode')
        self.mode,self.fixed,self.lifetime=mode,fixed,lifetime
        self.now=0; self.tokens={}; self.serial=0
    def login(self,user):
        self.serial+=1; token=f'synthetic-{user}-{self.serial}'
        self.tokens[token]={'user':user,'issued':self.now,'last':self.now}
        return token
    def access(self,token):
        row=self.tokens.get(token)
        if row is None:return 401,{'error':'missing_artifact'}
        base=row['issued'] if self.mode=='absolute' else row['last']
        if self.fixed and self.now>=base+self.lifetime:return 401,{'error':self.mode+'_expired'}
        row['last']=self.now
        return 200,{'resource':'profile','principal':row['user']}

def scenario(mode,variant):
    fixed=variant=='fixed';fixture=Fixture(mode,fixed)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            url=urlsplit(self.path)
            if url.path=='/login':
                user=parse_qs(url.query).get('user',[''])[0]
                if user not in ('alice','bob'):status,body=400,{'error':'invalid_user'}
                else:status,body=200,{'token':fixture.login(user)}
            elif url.path=='/protected':status,body=fixture.access(self.headers.get('Authorization','').removeprefix('Bearer '))
            else:status,body=404,{'error':'unknown_path'}
            data=json.dumps(body).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    server.daemon_threads=True;thread=Thread(target=server.serve_forever,kwargs={'poll_interval':.01},daemon=True);thread.start()
    steps=[]
    def call(path,token=None,alias=None):
        req=Request(f'http://127.0.0.1:{server.server_port}'+path,headers={'Authorization':'Bearer '+token} if token else {})
        try:
            with urlopen(req,timeout=3) as response:status=response.status;body=json.load(response)
        except HTTPError as e:status=e.code;body=json.load(e)
        # Never serialize bearer tokens, response credentials, ports or wall clocks.
        steps.append({'step':len(steps)+1,'clock_s':fixture.now,'endpoint':urlsplit(path).path,'artifact_alias':alias,'status':status,
                      'outcome':body.get('error') or ('token_issued' if 'token' in body else 'protected_operation'),
                      'principal':body.get('principal')})
        return status,body
    try:
        status,body=call('/login?user=alice',alias='alice_initial');old=body['token']
        pre=call('/protected',old,'alice_initial')
        fixture.now=9;before=call('/protected',old,'alice_initial')
        # Last valid idle use is t=9, so its new idle boundary is t=19.
        boundary=19 if mode=='idle' else 10
        fixture.now=boundary-1;_,b=call('/login?user=bob',alias='bob_unrelated');bob=b['token']
        call('/protected',bob,'bob_unrelated')
        fixture.now=boundary;replay=call('/protected',old,'alice_initial')
        _,a=call('/login?user=alice',alias='alice_fresh');fresh=call('/protected',a['token'],'alice_fresh')
        unrelated=call('/protected',bob,'bob_unrelated')
        baseline=pre==(200,{'resource':'profile','principal':'alice'}) and before==(200,{'resource':'profile','principal':'alice'})
        denial=replay==(401,{'error':mode+'_expired'})
        success=replay==(200,{'resource':'profile','principal':'alice'})
        controls={'pre_condition_access':baseline,'fresh_login_access':fresh==(200,{'resource':'profile','principal':'alice'}),'unrelated_user_access':unrelated==(200,{'resource':'profile','principal':'bob'})}
        return {'id':'M7' if mode=='idle' else 'M8','paper_class':'T','mode':mode,'variant':variant,
                'normative_basis':'synthetic_lab_policy','clock':'manually_advanced_seconds','lifetime_s':10,'boundary_s':boundary,
                'expected':'deny_at_boundary' if fixed else 'residual_access_at_boundary','replay_status':replay[0],
                'scenario_valid':baseline,'contract_satisfied':baseline and (denial if fixed else success) and all(controls.values()),
                'controls':controls,'n_http_steps':len(steps),'steps':steps}
    finally:
        server.shutdown();server.server_close();thread.join(timeout=3)

def run():
    rows=[scenario(mode,variant) for mode in ('idle','absolute') for variant in ('vulnerable','fixed')]
    return {'schema':'sesstrace-expiration/1.0','provenance':'Added during artifact revision; not part of the original six-withdrawal-witness result.',
            'scenarios':rows,'summary':{'n_mechanisms':2,'n_scenarios':len(rows),'n_http_steps':sum(r['n_http_steps'] for r in rows),'controls_passed':sum(sum(r['controls'].values()) for r in rows),'controls_total':sum(len(r['controls']) for r in rows),'all_clean':all(r['contract_satisfied'] for r in rows)}}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out-dir',type=Path,default=Path(__file__).resolve().parent.parent/'build/expiration');a=p.parse_args()
    result=run();a.out_dir.mkdir(parents=True,exist_ok=True)
    (a.out_dir/'expiry_results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(result['summary']))
    if not result['summary']['all_clean']:raise SystemExit(1)
if __name__=='__main__':main()
